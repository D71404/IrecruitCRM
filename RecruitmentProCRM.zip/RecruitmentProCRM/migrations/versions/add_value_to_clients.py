
"""Add value column to clients

Revision ID: add_value_to_clients
Revises: 8a525049c4da
Create Date: 2024-12-22 05:30:00.000000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'add_value_to_clients'
down_revision = '8a525049c4da'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('clients', sa.Column('value', sa.Numeric(10, 2), nullable=False, server_default='0'))

def downgrade():
    op.drop_column('clients', 'value')
