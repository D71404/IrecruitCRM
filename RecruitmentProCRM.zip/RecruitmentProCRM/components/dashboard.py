import streamlit as st
from models.database import Database
from models.auth import Auth
import pandas as pd

def render_dashboard():
    st.title("📊 Recruitment Dashboard")

    try:
        db = Database()
        auth = Auth()

        # Check if user has permission to view client value metrics
        has_value_permission = False
        if 'user' in st.session_state and st.session_state.user:
            has_value_permission = auth.can_view_client_value(st.session_state.user['id'])
    except Exception as e:
        st.error(f"Error connecting to database: {str(e)}")
        return

    try:
        # Key Metrics Section
        st.markdown("""
            <style>
            .dashboard-container {
                max-width: 1400px;
                margin: 0 auto;
                padding: 2rem;
            }
            .metric-card {
                background-color: white;
                padding: 1.75rem;
                border-radius: 1rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                margin: 0.5rem;
                min-height: 200px;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            .metric-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            }
            .metric-card h3 {
                color: #475569;
                font-size: 1.1rem;
                margin-bottom: 1.25rem;
                height: 28px;
                line-height: 28px;
                font-weight: 600;
                text-align: center;
                letter-spacing: 0.025em;
            }
            .metric-card h2 {
                color: #1e293b;
                font-size: 2rem;
                margin: 1.25rem 0;
                font-weight: 700;
                text-align: center;
                flex-grow: 0;
                letter-spacing: -0.025em;
            }
            .metric-card p {
                color: #64748b;
                font-size: 0.95rem;
                margin: 0.75rem 0;
                line-height: 1.5;
                text-align: center;
            }

            .section-container {
                margin: 2.5rem 0;
                padding: 1.5rem;
                background-color: white;
                border-radius: 1rem;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }

            .section-header {
                color: #1e293b;
                font-size: 1.5rem;
                font-weight: 600;
                margin-bottom: 2rem;
                padding-bottom: 0.75rem;
                border-bottom: 2px solid #e2e8f0;
            }

            .status-metrics {
                display: flex;
                flex-direction: column;
                gap: 1rem;
                padding: 0.75rem 0;
            }

            .status-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.75rem 1rem;
                border-radius: 0.75rem;
                background-color: #f8fafc;
                transition: all 0.2s ease;
            }

            .status-item:hover {
                background-color: #f1f5f9;
                transform: translateX(4px);
            }

            .status-item:hover {
                background-color: #f1f5f9;
            }

            .status-label {
                font-weight: 500;
                font-size: 0.875rem;
            }

            .status-count {
                font-weight: 600;
                font-size: 0.875rem;
                color: #1e293b;
            }

            .status-percentage {
                font-weight: 400;
                color: #64748b;
                margin-left: 0.25rem;
                font-size: 0.75rem;
            }

            /* Task and Candidate Card Styles */
            .task-card {
                background-color: white;
                border-radius: 0.75rem;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                padding: 1.5rem;
                margin-bottom: 1rem;
                transition: transform 0.2s, box-shadow 0.2s;
            }

            .task-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            }

            .task-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 1rem;
                border-bottom: 1px solid #e2e8f0;
                padding-bottom: 0.75rem;
            }

            .task-title {
                font-size: 1.25rem;
                font-weight: 600;
                color: #1e293b;
            }

            .task-info {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
                margin-bottom: 1rem;
            }

            .task-status {
                display: inline-flex;
                align-items: center;
                padding: 0.25rem 0.75rem;
                border-radius: 9999px;
                font-size: 0.875rem;
                font-weight: 500;
            }

            .status-high {
                background-color: #fee2e2;
                color: #ef4444;
            }

            .status-medium {
                background-color: #fef3c7;
                color: #f59e0b;
            }

            .status-normal {
                background-color: #dcfce7;
                color: #22c55e;
            }

            .task-description {
                font-size: 0.875rem;
                color: #475569;
                line-height: 1.5;
                margin-bottom: 1rem;
            }

            .task-meta {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.875rem;
                color: #64748b;
            }
            .status-indicator {
                display: inline-block;
                padding: 0.25rem 0.75rem;
                border-radius: 9999px;
                font-size: 0.875rem;
                font-weight: 500;
            }
            .dashboard-container {
                padding: 1.5rem;
                max-width: 1280px;
                margin: 0 auto;
            }
            div[data-testid="stHorizontalBlock"] {
                gap: 1.5rem;
                padding: 1rem;
            }
            div[data-testid="stHorizontalBlock"] > div {
                padding: 0 !important;
                flex: 1;
            }
            </style>
        """, unsafe_allow_html=True)

        # Create columns for metrics
        col1, col2, col3 = st.columns(3)

        # Total Client Value
        with col1:
            try:
                value_metrics = db.execute_one("""
                    WITH client_metrics AS (
                        SELECT 
                            COALESCE(SUM(value), 0) as total_value,
                            COALESCE(AVG(value), 0) as avg_value,
                            COUNT(*) as total_clients
                        FROM clients
                        WHERE status = 'Active'
                    )
                    SELECT 
                        CONCAT('£', TO_CHAR(total_value, 'FM999,999,999.00')) as total_value,
                        CONCAT('£', TO_CHAR(avg_value, 'FM999,999.00')) as avg_value,
                        total_clients
                    FROM client_metrics
                """)
                total_value = value_metrics['total_value'] if value_metrics else '£0.00'
                avg_value = value_metrics['avg_value'] if value_metrics else '£0.00'
                total_clients = value_metrics['total_clients'] if value_metrics else 0
            except Exception as e:
                st.error(f"Error fetching client value: {str(e)}")
                total_value = '£0.00'
                avg_value = '£0.00'
                growth_indicator = ""

            clients_stats = db.execute_one("""
                SELECT 
                    COUNT(*) FILTER (WHERE status = 'Active') as active_count,
                    COUNT(*) FILTER (WHERE status != 'Active') as inactive_count,
                    COUNT(*) as total_count
                FROM clients
            """)
            active_count = clients_stats['active_count'] if clients_stats else 0
            inactive_count = clients_stats['inactive_count'] if clients_stats else 0
            total_count = clients_stats['total_count'] if clients_stats else 0

            if has_value_permission:
                st.markdown(f"""
                    <div class="metric-card">
                        <h3>💰 Client Value Metrics</h3>
                        <h2>{total_value}</h2>
                        <div class="status-metrics">
                            <div class="status-item">
                                <div class="status-label" style="color: #22c55e;">Active</div>
                                <div class="status-count">
                                    {active_count}
                                    <span class="status-percentage">({(active_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                                </div>
                            </div>
                            <div class="status-item">
                                <div class="status-label" style="color: #ef4444;">Inactive</div>
                                <div class="status-count">
                                    {inactive_count}
                                    <span class="status-percentage">({(inactive_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                                </div>
                            </div>
                        </div>
                        <p>Average Value: {avg_value}</p>
                    </div>
                """, unsafe_allow_html=True)

                # Add note about detailed metrics in reports
                st.markdown("""
                    <div style="margin-top: 1rem; padding: 0.75rem; background-color: #f8fafc; border-radius: 0.5rem;">
                        <p style="margin: 0; color: #64748b;">
                            <i>View detailed value metrics and charts in the Reports section</i>
                        </p>
                    </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                    <div class="metric-card">
                        <h3>💰 Client Metrics</h3>
                        <h2>{total_count}</h2>
                        <div class="status-metrics">
                            <div class="status-item">
                                <div class="status-label" style="color: #22c55e;">Active</div>
                                <div class="status-count">
                                    {active_count}
                                    <span class="status-percentage">({(active_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                                </div>
                            </div>
                            <div class="status-item">
                                <div class="status-label" style="color: #ef4444;">Inactive</div>
                                <div class="status-count">
                                    {inactive_count}
                                    <span class="status-percentage">({(inactive_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                                </div>
                            </div>
                        </div>
                        <p><i>Contact admin for detailed value metrics</i></p>
                    </div>
                """, unsafe_allow_html=True)

        # Total Candidates
        with col2:
            try:
                candidates_stats = db.execute_one("""
                    SELECT 
                        COUNT(*) FILTER (WHERE status != 'Inactive') as active_count,
                        COUNT(*) FILTER (WHERE status = 'Inactive') as inactive_count,
                        COUNT(*) as total_count
                    FROM candidates
                """)
                active_count = candidates_stats['active_count'] if candidates_stats else 0
                inactive_count = candidates_stats['inactive_count'] if candidates_stats else 0
                total_count = candidates_stats['total_count'] if candidates_stats else 0
            except Exception as e:
                st.error(f"Error fetching candidate count: {str(e)}")
                active_count = inactive_count = total_count = 0

            st.markdown(f"""
                <div class="metric-card">
                    <h3>👥 Candidate Statistics</h3>
                    <h2>{total_count}</h2>
                    <div class="status-metrics">
                        <div class="status-item">
                            <div class="status-label" style="color: #22c55e;">Active</div>
                            <div class="status-count">
                                {active_count}
                                <span class="status-percentage">({(active_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                            </div>
                        </div>
                        <div class="status-item">
                            <div class="status-label" style="color: #ef4444;">Inactive</div>
                            <div class="status-count">
                                {inactive_count}
                                <span class="status-percentage">({(inactive_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                            </div>
                        </div>
                    </div>
                </div>
            """, unsafe_allow_html=True)

        # Jobs Statistics
        with col3:
            try:
                jobs_stats = db.execute_one("""
                    SELECT 
                        COUNT(*) FILTER (WHERE status = 'Active') as active_count,
                        COUNT(*) FILTER (WHERE status != 'Active') as inactive_count,
                        COUNT(*) as total_count
                    FROM jobs
                """)
                active_count = jobs_stats['active_count'] if jobs_stats else 0
                inactive_count = jobs_stats['inactive_count'] if jobs_stats else 0
                total_count = jobs_stats['total_count'] if jobs_stats else 0
            except Exception as e:
                st.error(f"Error fetching jobs count: {str(e)}")
                active_count = inactive_count = total_count = 0

            st.markdown(f"""
                <div class="metric-card">
                    <h3>💼 Job Statistics</h3>
                    <h2>{total_count}</h2>
                    <div class="status-metrics">
                        <div class="status-item">
                            <div class="status-label" style="color: #22c55e;">Active</div>
                            <div class="status-count">
                                {active_count}
                                <span class="status-percentage">({(active_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                            </div>
                        </div>
                        <div class="status-item">
                            <div class="status-label" style="color: #ef4444;">Inactive</div>
                            <div class="status-count">
                                {inactive_count}
                                <span class="status-percentage">({(inactive_count/total_count*100 if total_count > 0 else 0):.1f}%)</span>
                            </div>
                        </div>
                    </div>
                </div>
            """, unsafe_allow_html=True)



        # Industry Distribution
        st.subheader("🏢 Industry Distribution")
        try:
            # Add filter buttons
            col_filters = st.columns(2)
            with col_filters[0]:
                candidates_filter = st.radio(
                    "Filter Candidates",
                    ["All", "Active", "Inactive"],
                    horizontal=True,
                    key="candidates_filter"
                )
            with col_filters[1]:
                jobs_filter = st.radio(
                    "Filter Jobs",
                    ["All", "Active", "Inactive"],
                    horizontal=True,
                    key="jobs_filter"
                )

            # Get candidates industry distribution
            candidates_where_clause = ""
            if candidates_filter != "All":
                candidates_where_clause = f"WHERE status = '{candidates_filter}'"

            candidates_industry = db.execute(f"""
                SELECT 
                    unnest(industry) as industry,
                    COUNT(*) as count
                FROM candidates
                {candidates_where_clause}
                GROUP BY unnest(industry)
                ORDER BY count DESC
            """)

            # Get jobs industry distribution
            jobs_where_clause = ""
            if jobs_filter != "All":
                jobs_where_clause = f"WHERE status = '{jobs_filter}'"

            jobs_industry = db.execute(f"""
                SELECT 
                    industry,
                    COUNT(*) as count
                FROM jobs
                {jobs_where_clause}
                GROUP BY industry
                ORDER BY count DESC
            """)

            # Create two columns for the pie charts
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### 👥 Candidates by Industry")
                if candidates_industry:
                    # Prepare data for candidates pie chart
                    candidates_labels = [row['industry'] for row in candidates_industry]
                    candidates_values = [row['count'] for row in candidates_industry]

                    import plotly.graph_objects as go
                    fig_candidates = go.Figure(data=[go.Pie(
                        labels=candidates_labels,
                        values=candidates_values,
                        hole=.3,
                        marker_colors=['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', 
                                        '#ec4899', '#14b8a6', '#f97316', '#06b6d4', '#6366f1']
                    )])
                    fig_candidates.update_layout(
                        showlegend=True,
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    st.plotly_chart(fig_candidates, use_container_width=True)

                    # Display detailed table for candidates
                    df_candidates = pd.DataFrame(candidates_industry)
                    st.dataframe(
                        df_candidates,
                        column_config={
                            "industry": st.column_config.TextColumn("Industry", width="medium"),
                            "count": st.column_config.NumberColumn("👥 Count", width="small"),
                        },
                        hide_index=True,
                        use_container_width=True
                    )
                else:
                    st.info("No candidate industry data available")

            with col2:
                st.markdown("### 💼 Jobs by Industry")
                if jobs_industry:
                    # Prepare data for jobs pie chart
                    jobs_labels = [row['industry'] for row in jobs_industry]
                    jobs_values = [row['count'] for row in jobs_industry]

                    fig_jobs = go.Figure(data=[go.Pie(
                        labels=jobs_labels,
                        values=jobs_values,
                        hole=.3,
                        marker_colors=['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', 
                                        '#ec4899', '#14b8a6', '#f97316', '#06b6d4', '#6366f1']
                    )])
                    fig_jobs.update_layout(
                        showlegend=True,
                        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                    )
                    st.plotly_chart(fig_jobs, use_container_width=True)

                    # Display detailed table for jobs
                    df_jobs = pd.DataFrame(jobs_industry)
                    st.dataframe(
                        df_jobs,
                        column_config={
                            "industry": st.column_config.TextColumn("Industry", width="medium"),
                            "count": st.column_config.NumberColumn("💼 Count", width="small"),
                        },
                        hide_index=True,
                        use_container_width=True
                    )
                else:
                    st.info("No jobs industry data available")
        except Exception as e:
            st.error(f"Error fetching industry distribution: {str(e)}")

        # Upcoming Tasks
        st.subheader("📅 Upcoming Tasks")
        try:
            upcoming_tasks = db.execute("""
                SELECT 
                    title,
                    description,
                    due_date,
                    status,
                    CASE
                        WHEN due_date < CURRENT_DATE THEN 'High'
                        WHEN due_date = CURRENT_DATE THEN 'Medium'
                        ELSE 'Normal'
                    END as priority,
                    CASE
                        WHEN due_date < CURRENT_DATE THEN 'Overdue'
                        WHEN due_date = CURRENT_DATE THEN 'Due Today'
                        ELSE CONCAT('Due in ', due_date - CURRENT_DATE, ' days')
                    END as due_status
                FROM tasks
                WHERE status != 'Completed'
                AND due_date <= CURRENT_DATE + INTERVAL '1 month'
                ORDER BY due_date DESC
                LIMIT 5
            """)

            if upcoming_tasks:
                for task in upcoming_tasks:
                    task_color = {
                        'Overdue': 'red',
                        'Due Today': 'orange'
                    }.get(task['due_status'], 'black')

                    priority_color = {
                        'High': 'red',
                        'Medium': 'orange',
                        'Normal': 'green'
                    }.get(task['priority'], 'black')

                    st.markdown(f"""
                        <div class="task-card">
                            <div class="task-header">
                                <div class="task-title">📅 {task['title']}</div>
                                <div class="task-status status-{task['priority'].lower()}">
                                    {task['due_status']}
                                </div>
                            </div>
                            <div class="task-info">
                                <div>
                                    <strong style="color: #475569;">Status:</strong>
                                    <span style="margin-left: 0.5rem;">{task['status']}</span>
                                </div>
                                <div>
                                    <strong style="color: #475569;">Priority:</strong>
                                    <span style="margin-left: 0.5rem; color: {priority_color};">
                                        {task['priority']}
                                    </span>
                                </div>
                                <div>
                                    <strong style="color: #475569;">Due Date:</strong>
                                    <span style="margin-left: 0.5rem;">
                                        {task['due_date'].strftime('%Y-%m-%d')}
                                    </span>
                                </div>
                                <div>
                                    <strong style="color: #475569;">Due Status:</strong>
                                    <span style="margin-left: 0.5rem; color: {task_color};">
                                        {task['due_status']}
                                    </span>
                                </div>
                            </div>
                            <div class="task-description">
                                {task['description']}
                            </div>
                        </div>
                    """, unsafe_allow_html=True)
            else:
                st.info("No upcoming tasks for the next 7 days")
        except Exception as e:
            st.error(f"Error fetching upcoming tasks: {str(e)}")

        # Recent Activity
        st.subheader("Recent Activity")
        col1, col2 = st.columns(2)

        # Recent Timesheets
        with col1:
            try:
                st.write("📋 Recent Timesheets")
                recent_timesheets = db.execute("""
                    SELECT 
                        t.date,
                        c.name as candidate,
                        j.title as job_title,
                        t.status
                    FROM timesheets t
                    JOIN candidates c ON t.candidate_id = c.id
                    JOIN jobs j ON t.job_id = j.id
                    ORDER BY t.created_at DESC
                    LIMIT 5
                """)

                if recent_timesheets:
                    df_timesheets = pd.DataFrame(recent_timesheets)
                    st.dataframe(
                        df_timesheets,
                        column_config={
                            "date": "Date",
                            "candidate": "Candidate",
                            "job_title": "Job",
                            "status": "Status"
                        },
                        hide_index=True
                    )
                else:
                    st.info("No recent timesheets")
            except Exception as e:
                st.error(f"Error fetching recent timesheets: {str(e)}")

        # Recent Clients
        with col2:
            try:
                st.write("🏢 Recent Clients")
                recent_clients = db.execute("""
                    SELECT 
                        name, 
                        company, 
                        industry,
                        status,
                        created_at
                    FROM clients
                    ORDER BY created_at DESC
                    LIMIT 5
                """)

                if recent_clients:
                    df_clients = pd.DataFrame(recent_clients)
                    st.dataframe(
                        df_clients,
                        column_config={
                            "name": "Name",
                            "company": "Company",
                            "industry": "Industry",
                            "status": "Status",
                            "created_at": "Created At"
                        },
                        hide_index=True
                    )
                else:
                    st.info("No recent clients")
            except Exception as e:
                st.error(f"Error fetching recent clients: {str(e)}")

    except Exception as e:
        st.error(f"Error rendering dashboard: {str(e)}")
    finally:
        try:
            db.close()
        except:
            pass