import streamlit as st
from models.auth import Auth

def render_navigation():
    st.sidebar.markdown("### Navigation")
    
    # Theme toggle
    if 'theme' not in st.session_state:
        st.session_state.theme = 'light'
    
    theme_button = st.sidebar.button('🌓 Toggle Dark Mode')
    
    # Apply theme styles based on current theme state
    if st.session_state.theme == 'dark':
        st.markdown("""
            <style>
                .stApp {background-color: #1E1E1E !important;}
                .main {background-color: #1E1E1E !important;}
                div[data-testid="stToolbar"] {background-color: #252526 !important;}
                .stTextInput input, .stTextArea textarea, .stSelectbox select {
                    background-color: #2D2D2D !important;
                    color: #FFFFFF !important;
                    border-color: #404040 !important;
                }
                .stDataFrame {background-color: #252526 !important;}
                [data-testid="stSidebar"] {background-color: #252526 !important;}
                button {color: white !important;}
                .stMarkdown {color: #FFFFFF !important;}
                p, h1, h2, h3, h4, h5, h6 {color: #FFFFFF !important;}
                .metric-card {background-color: #252526 !important; color: #FFFFFF !important;}
                .task-card {background-color: #252526 !important;}
                thead tr th {background-color: #252526 !important; color: #FFFFFF !important;}
                tbody tr {background-color: #2D2D2D !important; color: #FFFFFF !important;}
            </style>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
            <style>
                .stApp {background-color: #FFFFFF !important;}
                .main {background-color: #FFFFFF !important;}
                div[data-testid="stToolbar"] {background-color: #F8F9FA !important;}
                .stTextInput input, .stTextArea textarea, .stSelectbox select {
                    background-color: #F8F9FA !important;
                    color: #000000 !important;
                    border-color: #CED4DA !important;
                }
                .stDataFrame {background-color: #FFFFFF !important;}
                [data-testid="stSidebar"] {background-color: #F8F9FA !important;}
                button {color: white !important;}
                .stMarkdown {color: #000000 !important;}
                p, h1, h2, h3, h4, h5, h6 {color: #000000 !important;}
                .metric-card {background-color: #FFFFFF !important; color: #000000 !important;}
                .task-card {background-color: #FFFFFF !important;}
                thead tr th {background-color: #F8F9FA !important; color: #000000 !important;}
                tbody tr {background-color: #FFFFFF !important; color: #000000 !important;}
            </style>
        """, unsafe_allow_html=True)
    
    # Handle theme toggle button click
    if theme_button:
        st.session_state.theme = 'light' if st.session_state.theme == 'dark' else 'dark'
        st.rerun()

    # Add custom styles for navigation
    st.markdown("""
        <style>
        .navbar {
            position: fixed;
            top: 0;
            right: 0;
            padding: 1rem;
            z-index: 999;
        }
        .user-info {
            display: inline-block;
            margin-right: 1rem;
            color: #1a1a1a;
            font-size: 0.9rem;
        }
        </style>
    """, unsafe_allow_html=True)

    # Only show navigation if user is authenticated
    if 'authenticated' in st.session_state and st.session_state.authenticated:
        st.markdown(
            f"""
            <div style="text-align: right; padding: 1rem;">
                <span style="color: #1a1a1a; margin-right: 1rem;">
                    {st.session_state.user.get('username', 'Unknown')} 
                    ({st.session_state.user.get('role', 'user')})
                </span>
            </div>
            """,
            unsafe_allow_html=True
        )
        if st.button('Logout', key='logout_button', type='primary'):
            handle_logout()
            st.rerun()

def handle_logout():
    if st.session_state.authenticated and st.session_state.user:
        auth = Auth()
        if auth.clear_session(st.session_state.user['id']):
            # Clear session state
            st.session_state.authenticated = False
            st.session_state.user = None
            st.session_state.session_id = None
            return True
    return False