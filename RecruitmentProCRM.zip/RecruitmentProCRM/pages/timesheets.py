import streamlit as st
from models.database import Database
from models.auth import Auth
import pandas as pd
from datetime import datetime
import psycopg2
from typing import Union
from io import BytesIO

def render():
    # Add custom CSS for form fields
    st.markdown("""
        <style>
        /* Form input styling */
        .stTextInput input, .stTextArea textarea, .stSelectbox select {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
        }

        /* Form field hover state */
        .stTextInput input:hover, .stTextArea textarea:hover, .stSelectbox select:hover {
            border-color: #888888;
        }

        /* Form field focus state */
        .stTextInput input:focus, .stTextArea textarea:focus, .stSelectbox select:focus {
            border-color: #0078FF;
            box-shadow: 0 0 0 1px #0078FF;
        }

        /* Date input styling */
        .stDateInput input {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
        }

        /* File uploader styling */
        .stFileUploader {
            background-color: #ffffff;
            border: 1px dashed #cccccc;
            padding: 1rem;
            border-radius: 4px;
        }
        </style>
    """, unsafe_allow_html=True)

    # Add loading placeholder
    with st.spinner("Loading Timesheet Management..."):
        st.title("Timesheet Management")
        
        # Initialize session state for form clearing
        if 'form_submitted' not in st.session_state:
            st.session_state.form_submitted = False
        
        # Add container for smooth transitions
        main_container = st.container()
        with main_container:
            db = Database()
    
    # Combined Timesheet Entry
    with st.expander("Timesheet Entry"):
        # Reset form if it was just submitted
        if st.session_state.form_submitted:
            st.session_state.form_submitted = False
            st.rerun()
            
        candidates = db.execute("SELECT id, name FROM candidates")
        jobs = db.execute("""
            SELECT j.id, j.title, c.name as client_name 
            FROM jobs j 
            JOIN clients c ON j.client_id = c.id 
            WHERE j.status = 'Active'
        """)
        
        with st.form("timesheet_entry", clear_on_submit=True):
            st.subheader("Manual Entry")
            # Candidate selection with required indicator
            st.markdown("##### Candidate Selection (Required)")
            if not candidates:
                st.warning("No candidates available")
                candidate_id = None
            else:
                candidate_id = st.selectbox(
                    "Select Candidate",
                    options=[c['id'] for c in candidates],
                    format_func=lambda x: next((c['name'] for c in candidates if c['id'] == x), ''),
                    help="This field is required"
                )
            
            # Job selection with required indicator
            st.markdown("##### Job Selection (Required)")
            if not jobs:
                st.warning("No active jobs available")
                job_id = None
            else:
                job_id = st.selectbox(
                    "Select Job",
                    options=[j['id'] for j in jobs],
                    format_func=lambda x: next((f"{j['title']} ({j['client_name']})" for j in jobs if j['id'] == x), ''),
                    help="This field is required"
                )
            
            # Month and Year selection
            col1, col2 = st.columns(2)
            with col1:
                month = st.selectbox(
                    "Month *",
                    range(1, 13),
                    format_func=lambda x: datetime.strftime(datetime(2000, x, 1), "%B")
                )
            with col2:
                year = st.selectbox(
                    "Year *",
                    [2024, 2025]
                )
    
            st.subheader("Or Upload Excel File")
            uploaded_file = st.file_uploader("Upload Timesheet Excel (Required for bulk upload)", type=['xlsx'])
            
            # Submit button
            submit_clicked = st.form_submit_button("Submit Timesheet")
            if submit_clicked:
                if uploaded_file is not None:
                    try:
                        df = pd.read_excel(uploaded_file)
                        # Display the uploaded data preview
                        st.write("Preview of uploaded data:")
                        st.dataframe(df.head())
                        
                        # Track processed entries to avoid duplicates
                        processed_entries = set()
                        
                        # Save each unique row to the database
                        for _, row in df.iterrows():
                            # Create a unique key for the entry
                            entry_key = (
                                str(row.get('candidate_id', candidate_id)),
                                str(row.get('job_id', job_id)),
                                str(row.get('date', datetime.now().date()))
                            )
                            
                            # Skip if already processed
                            if entry_key in processed_entries:
                                continue
                            
                            processed_entries.add(entry_key)
                            
                            # Convert date if it exists in the Excel
                            timesheet_date = row.get('date', datetime.now().date())
                            if isinstance(timesheet_date, str):
                                try:
                                    timesheet_date = datetime.strptime(timesheet_date, '%Y-%m-%d').date()
                                except ValueError:
                                    timesheet_date = datetime.now().date()
                            
                            # Handle file content
                            file_content = None
                            original_filename = None
                            if uploaded_file:
                                original_filename = uploaded_file.name
                                # Preserve the exact binary content of the Excel file
                                uploaded_file.seek(0)
                                file_content = uploaded_file.read()
                            
                            db.execute_update(
                                """
                                INSERT INTO timesheets (candidate_id, job_id, date, status, original_file, original_filename)
                                VALUES (%s, %s, %s, %s, %s, %s)
                                """,
                                (row.get('candidate_id', candidate_id), 
                                 row.get('job_id', job_id), 
                                 timesheet_date, 
                                 "Pending",
                                 psycopg2.Binary(file_content) if file_content else None,
                                 original_filename)
                            )
                        
                        st.success(f"Successfully processed {len(processed_entries)} unique timesheet entries!")
                        st.session_state.form_submitted = True
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error processing file: {str(e)}")
                else:
                    # Enhanced validation for manual entry
                    validation_errors = []
                    if not candidate_id:
                        validation_errors.append("Candidate selection is required")
                    if not job_id:
                        validation_errors.append("Job selection is required")
                    
                    if validation_errors:
                        for error in validation_errors:
                            st.error(error)
                        return
                    
                    try:
                        # Create date from month and year (use first day of month)
                        timesheet_date = datetime(year, month, 1).date()
                        
                        db.execute_update(
                            """
                            INSERT INTO timesheets (candidate_id, job_id, date, status)
                            VALUES (%s, %s, %s, %s)
                            """,
                            (candidate_id, job_id, timesheet_date, "Pending")
                        )
                        st.success("Timesheet submitted successfully!")
                        st.session_state.form_submitted = True
                        st.rerun()
                    except Exception as e:
                        if "violates not-null constraint" in str(e):
                            st.error("Candidate ID and Job ID are required fields")
                        else:
                            st.error(f"Error submitting timesheet: {str(e)}")
    
    # View timesheets
    st.subheader("Recent Timesheet Submissions")
    
    timesheets = db.execute("""
        WITH latest_submissions AS (
            SELECT DISTINCT ON (t.candidate_id)
                t.candidate_id,
                c.name as candidate_name,
                COUNT(*) OVER (PARTITION BY t.candidate_id) as submission_count,
                MAX(t.date) OVER (PARTITION BY t.candidate_id) as latest_submission
            FROM timesheets t
            JOIN candidates c ON t.candidate_id = c.id
            ORDER BY t.candidate_id, t.date DESC
        ),
        job_titles AS (
            SELECT 
                t.candidate_id,
                string_agg(DISTINCT j.title, ', ' ORDER BY j.title) as job_titles
            FROM timesheets t
            JOIN jobs j ON t.job_id = j.id
            GROUP BY t.candidate_id
        )
        SELECT 
            ls.candidate_name,
            ls.submission_count,
            ls.latest_submission,
            COALESCE(jt.job_titles, 'No jobs') as job_titles
        FROM latest_submissions ls
        LEFT JOIN job_titles jt ON ls.candidate_id = jt.candidate_id
        ORDER BY ls.latest_submission DESC
    """)
    
    if timesheets:
        df = pd.DataFrame(timesheets)
        st.dataframe(
            df,
            column_config={
                "candidate_name": "Candidate Name",
                "submission_count": "Total Submissions",
                "latest_submission": "Latest Submission Date",
                "job_titles": "Associated Jobs"
            },
            hide_index=True,
            use_container_width=True
        )
    else:
        st.info("No timesheet submissions found")
    
    # Update timesheet status
    with st.expander("Update Timesheet Status"):
        pending_timesheets = db.execute("""
            SELECT t.id, c.name as candidate_name, j.title as job_title, t.date
            FROM timesheets t
            JOIN candidates c ON t.candidate_id = c.id
            JOIN jobs j ON t.job_id = j.id
            WHERE t.status = 'Pending'
        """)
        
        if pending_timesheets:
            selected_timesheet = st.selectbox(
                "Select Timesheet",
                options=pending_timesheets,
                format_func=lambda x: f"{x['candidate_name']} - {x['job_title']} ({x['date']})"
            )
            
            new_status = st.selectbox(
                "New Status",
                ["Pending", "Approved", "Rejected"]
            )
            
            if st.button("Update Status"):
                db.execute_update(
                    "UPDATE timesheets SET status = %s WHERE id = %s",
                    (new_status, selected_timesheet['id'])
                )
                db.commit()
                st.success("Status updated successfully!")
        else:
            st.info("No pending timesheets")
    # Delete Timesheets Section
    with st.expander("🗑️ Delete Timesheets"):
        auth = Auth()
        if not auth.can_delete_timesheets(st.session_state.user['id']):
            st.error("🚫 You don't have permission to delete timesheets. This feature is restricted to administrators.")
        else:
            st.subheader("Delete Timesheet Entries")
            
            # Get all timesheets with details
            all_timesheets = db.execute("""
                SELECT 
                    t.id,
                    c.name as candidate_name,
                    j.title as job_title,
                    t.date,
                    t.status
                FROM timesheets t
                JOIN candidates c ON t.candidate_id = c.id
                JOIN jobs j ON t.job_id = j.id
                ORDER BY t.date DESC
            """)
            
            if all_timesheets:
                selected_timesheet = st.selectbox(
                    "Select Timesheet to Delete",
                    options=all_timesheets,
                    format_func=lambda x: f"{x['candidate_name']} - {x['job_title']} ({x['date']})"
                )
                
                if st.button("Delete Selected Timesheet", type="primary", help="This action cannot be undone"):
                    try:
                        db.execute_update(
                            "DELETE FROM timesheets WHERE id = %s",
                            (selected_timesheet['id'],)
                        )
                        st.success("Timesheet deleted successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error deleting timesheet: {str(e)}")
            else:
                st.info("No timesheets available to delete")
    
    # Download Timesheets Section
    with st.expander("⬇️ Download Timesheets"):
        st.subheader("Download Candidate Timesheets")
        
        # Get all candidates with timesheets
        candidates_with_timesheets = db.execute("""
            SELECT DISTINCT c.id, c.name 
            FROM candidates c
            JOIN timesheets t ON c.id = t.candidate_id
            ORDER BY c.name
        """)
        
        if candidates_with_timesheets:
            selected_candidate = st.selectbox(
                "Select Candidate",
                options=candidates_with_timesheets,
                format_func=lambda x: x['name'],
                key="timesheet_download_candidate"
            )
            
            if selected_candidate:
                # Fetch detailed timesheet data for the selected candidate
                timesheet_data = db.execute("""
                    SELECT 
                        t.date,
                        j.title as job_title,
                        COALESCE(cl.name, 'N/A') as client_name,
                        t.status,
                        t.created_at
                    FROM timesheets t
                    LEFT JOIN jobs j ON t.job_id = j.id
                    LEFT JOIN clients cl ON j.client_id = cl.id
                    WHERE t.candidate_id = %s
                    ORDER BY t.date DESC
                """, (selected_candidate['id'],))
                
                if timesheet_data:
                    # Convert to DataFrame for display and download
                    df = pd.DataFrame(timesheet_data)
                    
                    # Format dates
                    df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
                    df['created_at'] = pd.to_datetime(df['created_at']).dt.strftime('%Y-%m-%d %H:%M:%S')
                    
                    # Display preview
                    st.write("Preview:")
                    st.dataframe(
                        df,
                        hide_index=True,
                        use_container_width=True
                    )
                    
                    # Get all original files for the candidate's timesheets
                    original_files = db.execute("""
                        SELECT 
                            t.original_file,
                            t.original_filename,
                            t.date,
                            j.title as job_title
                        FROM timesheets t
                        LEFT JOIN jobs j ON t.job_id = j.id
                        WHERE t.candidate_id = %s
                        AND t.original_file IS NOT NULL
                        ORDER BY t.date DESC
                    """, (selected_candidate['id'],))
    
                    if original_files:
                        st.subheader("Original Timesheet Files")
                        for file in original_files:
                            if file['original_file']:
                                if isinstance(file['original_file'], memoryview):
                                    file_bytes = file['original_file'].tobytes()
                                else:
                                    file_bytes = bytes(file['original_file'])
                                
                                st.download_button(
                                    label=f"📥 Download Original Timesheet - {file['job_title']} ({file['date'].strftime('%Y-%m-%d')})",
                                    data=file_bytes,
                                    file_name=file['original_filename'] or f"timesheet_{file['date'].strftime('%Y-%m-%d')}.xlsx",
                                    mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                    key=f"download_original_timesheet_{file['date']}"
                                )
                    
                    # Also provide CSV download
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download as CSV",
                        data=csv,
                        file_name=f"timesheets_{selected_candidate['name'].replace(' ', '_')}_{datetime.now().strftime('%Y%m%d')}.csv",
                        mime='text/csv',
                        key="download_timesheet"
                    )
                else:
                    st.info("No timesheet data available for this candidate")
        else:
            st.info("No candidates with timesheets found")