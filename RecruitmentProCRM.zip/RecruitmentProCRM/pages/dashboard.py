import streamlit as st
from models.database import Database
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from streamlit_calendar import calendar

def render():
    st.title("📊 Dashboard")

    db = Database()

    # Add CSS for modern styling
    st.markdown("""
        <style>
        .metric-card {
            background-color: white;
            padding: 1.5rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin: 1rem 0;
            transition: transform 0.2s;
        }
        .metric-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        .metric-title {
            color: #475569;
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        .metric-value {
            color: #1e293b;
            font-size: 2rem;
            font-weight: 700;
            margin: 0.5rem 0;
        }
        .metric-subtitle {
            color: #64748b;
            font-size: 0.9rem;
        }
        .status-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.75rem;
            margin-top: 0.75rem;
        }
        .status-item {
            padding: 0.5rem;
            border-radius: 0.5rem;
            background-color: #f8fafc;
        }
        </style>
    """, unsafe_allow_html=True)

    # Create columns for metrics
    col1, col2, col3 = st.columns(3)

    # Client Metrics
    with col1:
        client_stats = db.execute_one("""
            SELECT 
                COUNT(*) FILTER (WHERE status = 'Active') as active_count,
                COUNT(*) FILTER (WHERE status = 'Inactive') as inactive_count,
                COUNT(*) as total_count,
                SUM(value) as total_value
            FROM clients
        """)
        
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">🏢 Clients</div>
                <div class="metric-value">{client_stats['total_count']}</div>
                <div class="metric-subtitle" style="font-size: 1.2rem; font-weight: 700;">Total Value: £{client_stats['total_value']:,.2f}</div>
                <div class="status-grid">
                    <div class="status-item">
                        <div style="color: #22c55e;">Active: {client_stats['active_count']}</div>
                    </div>
                    <div class="status-item">
                        <div style="color: #ef4444;">Inactive: {client_stats['inactive_count']}</div>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)

    # Candidate Metrics
    with col2:
        candidate_stats = db.execute_one("""
            SELECT 
                COUNT(*) FILTER (WHERE status = 'Active') as active_count,
                COUNT(*) FILTER (WHERE status = 'Inactive') as inactive_count,
                COUNT(*) as total_count
            FROM candidates
        """)
        
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">👥 Candidates</div>
                <div class="metric-value">{candidate_stats['total_count']}</div>
                <div class="status-grid">
                    <div class="status-item">
                        <div style="color: #22c55e;">Active: {candidate_stats['active_count']}</div>
                    </div>
                    <div class="status-item">
                        <div style="color: #ef4444;">Inactive: {candidate_stats['inactive_count']}</div>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)

    # Job Metrics
    with col3:
        job_stats = db.execute_one("""
            SELECT 
                COUNT(*) FILTER (WHERE status = 'Active') as active_count,
                COUNT(*) FILTER (WHERE status = 'Inactive') as inactive_count,
                COUNT(*) as total_count
            FROM jobs
        """)
        
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">💼 Jobs</div>
                <div class="metric-value">{job_stats['total_count']}</div>
                <div class="status-grid">
                    <div class="status-item">
                        <div style="color: #22c55e;">Active: {job_stats['active_count']}</div>
                    </div>
                    <div class="status-item">
                        <div style="color: #ef4444;">Inactive: {job_stats['inactive_count']}</div>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)

    # Create columns for industry charts
    col1, col2 = st.columns(2)

    # Candidates Industry Distribution Chart
    with col1:
        st.markdown("### 👥 Candidates by Industry")
        industry_status = st.radio(
            "Filter by Status",
            ["All", "Active", "Inactive"],
            horizontal=True,
            key="candidates_status_filter"
        )
        
        # Modify query based on status filter for candidates
        candidates_query = """
            SELECT unnest(industry) as industry, COUNT(*) as count 
            FROM candidates
            {}
            GROUP BY unnest(industry)
        """
        
        where_clause = " WHERE status = %s" if industry_status != "All" else ""
        query_params = (industry_status,) if industry_status != "All" else None
        
        candidates_industry = pd.DataFrame(
            db.execute(candidates_query.format(where_clause), query_params) if query_params 
            else db.execute(candidates_query.format(""))
        )

    # Jobs Industry Distribution Chart
    with col2:
        st.markdown("### 💼 Jobs by Industry")
        jobs_status = st.radio(
            "Filter by Status",
            ["All", "Active", "Inactive"],
            horizontal=True,
            key="jobs_status_filter"
        )
        
        # Modify query based on status filter for jobs
        jobs_query = """
            SELECT industry, COUNT(*) as count 
            FROM jobs
            {}
            GROUP BY industry
        """
        
        where_clause = " WHERE status = %s" if jobs_status != "All" else ""
        query_params = (jobs_status,) if jobs_status != "All" else None
        
        jobs_industry = pd.DataFrame(
            db.execute(jobs_query.format(where_clause), query_params) if query_params 
            else db.execute(jobs_query.format(""))
        )
    
    # This section is now handled above in the individual chart queries
    
    with col1:
        if not candidates_industry.empty:
            fig_candidates = px.pie(
                candidates_industry,
                values='count',
                names='industry',
                hole=0.3,
                color_discrete_sequence=['#E74C3C', '#F39C12', '#2ECC71', '#3498DB', '#9B59B6',
                                   '#1ABC9C', '#E67E22', '#27AE60', '#2980B9', '#8E44AD']
            )
            fig_candidates.update_layout(
                showlegend=True,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_candidates, use_container_width=True)
        else:
            st.info("No candidates industry data available")

    with col2:
        if not jobs_industry.empty:
            fig_jobs = px.pie(
                jobs_industry,
                values='count',
                names='industry',
                hole=0.3,
                color_discrete_sequence=['#E74C3C', '#F39C12', '#2ECC71', '#3498DB', '#9B59B6',
                                   '#1ABC9C', '#E67E22', '#27AE60', '#2980B9', '#8E44AD']
            )
            fig_jobs.update_layout(
                showlegend=True,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_jobs, use_container_width=True)
        else:
            st.info("No jobs industry data available")


    

    # Task Overview Section
    st.subheader("📋 Task Overview")
    
    task_stats = db.execute_one("""
        SELECT 
            COUNT(*) FILTER (WHERE status = 'New') as new_tasks,
            COUNT(*) FILTER (WHERE status = 'In Progress') as in_progress,
            COUNT(*) FILTER (WHERE status = 'On Hold') as on_hold,
            COUNT(*) FILTER (WHERE status = 'Completed') as completed,
            COUNT(*) FILTER (WHERE due_date < CURRENT_DATE AND status != 'Completed') as overdue
        FROM tasks
    """)

    task_cols = st.columns(5)
    with task_cols[0]:
        st.markdown("""
            <div class="metric-card">
                <div class="metric-subtitle">New</div>
                <div class="metric-value" style="color: #3b82f6;">{}</div>
            </div>
        """.format(task_stats['new_tasks']), unsafe_allow_html=True)
    
    with task_cols[1]:
        st.markdown("""
            <div class="metric-card">
                <div class="metric-subtitle">In Progress</div>
                <div class="metric-value" style="color: #f59e0b;">{}</div>
            </div>
        """.format(task_stats['in_progress']), unsafe_allow_html=True)
    
    with task_cols[2]:
        st.markdown("""
            <div class="metric-card">
                <div class="metric-subtitle">On Hold</div>
                <div class="metric-value" style="color: #8b5cf6;">{}</div>
            </div>
        """.format(task_stats['on_hold']), unsafe_allow_html=True)
    
    with task_cols[3]:
        st.markdown("""
            <div class="metric-card">
                <div class="metric-subtitle">Completed</div>
                <div class="metric-value" style="color: #22c55e;">{}</div>
            </div>
        """.format(task_stats['completed']), unsafe_allow_html=True)
    
    with task_cols[4]:
        st.markdown("""
            <div class="metric-card">
                <div class="metric-subtitle">Overdue</div>
                <div class="metric-value" style="color: #ef4444;">{}</div>
            </div>
        """.format(task_stats['overdue']), unsafe_allow_html=True)

    # Tasks and Calendar Section
    st.markdown("### 📅 Tasks & Calendar")
    
    # Create two columns for tasks and calendar
    tasks_col, calendar_col = st.columns([1, 1])
    
    with tasks_col:
        upcoming_tasks = db.execute("""
            SELECT 
                title,
                description,
                due_date,
                status,
                CASE
                    WHEN due_date < CURRENT_DATE THEN 'Overdue'
                    WHEN due_date = CURRENT_DATE THEN '0'
                    ELSE (due_date - CURRENT_DATE)::text
                END as days_left
            FROM tasks
            WHERE status != 'Completed'
            ORDER BY due_date ASC
            LIMIT 5
        """)
        
        st.markdown("""
            <style>
            .task-card {
                background-color: white;
                padding: 1rem;
                border-radius: 0.5rem;
                margin-bottom: 0.75rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .task-header {
                display: flex;
                justify-content: space-between;
                margin-bottom: 0.5rem;
            }
            .task-title {
                font-weight: 600;
                color: #1e293b;
            }
            .days-left {
                padding: 0.25rem 0.75rem;
                border-radius: 1rem;
                font-size: 0.875rem;
            }
            .task-description {
                color: #64748b;
                font-size: 0.875rem;
            }
            </style>
        """, unsafe_allow_html=True)
        
        for task in upcoming_tasks:
            days_text = (
                "Overdue" if task['days_left'] == 'Overdue'
                else "Due Today" if task['days_left'] == '0'
                else f"{task['days_left']} days left"
            )
            
            status_color = (
                "#ef4444" if task['days_left'] == 'Overdue'
                else "#f59e0b" if task['days_left'] == '0'
                else "#22c55e"
            )
            
            st.markdown(f"""
                <div class="task-card">
                    <div class="task-header">
                        <div class="task-title">{task['title']}</div>
                        <div class="days-left" style="background-color: {status_color}20; color: {status_color}">
                            {days_text}
                        </div>
                    </div>
                    <div class="task-description">
                        {task['description']}
                    </div>
                </div>
            """, unsafe_allow_html=True)
    
    with calendar_col:
        calendar_tasks = db.execute("""
            SELECT id, title, description, due_date, status
            FROM tasks
            WHERE due_date >= CURRENT_DATE - INTERVAL '30 days'
            AND due_date <= CURRENT_DATE + INTERVAL '30 days'
        """)
        
        calendar_events = []
        for task in calendar_tasks:
            color = {
                'New': '#3b82f6',
                'In Progress': '#f59e0b',
                'Completed': '#22c55e',
                'On Hold': '#ef4444'
            }.get(task['status'], '#64748b')
            
            calendar_events.append({
                'title': task['title'],
                'start': task['due_date'].isoformat(),
                'end': task['due_date'].isoformat(),
                'backgroundColor': color,
                'borderColor': color,
                'extendedProps': {
                    'description': task['description'],
                    'status': task['status']
                }
            })
        
        calendar_options = {
            "initialView": "dayGridMonth",
            "headerToolbar": {
                "left": "prev,next today",
                "center": "title",
                "right": "dayGridMonth,dayGridWeek"
            },
            "height": 450,
            "aspectRatio": 1.5
        }
        
        calendar({"events": calendar_events, "options": calendar_options})

    