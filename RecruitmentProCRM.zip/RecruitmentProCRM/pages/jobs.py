import streamlit as st
from models.auth import Auth
from models.database import Database
import pandas as pd
from utils.constants import VALID_INDUSTRIES
import json

def init_session_state():
    if 'job_form' not in st.session_state:
        default_industry = VALID_INDUSTRIES[0] if VALID_INDUSTRIES else ''
        st.session_state.job_form = {
            'title': '',
            'client_id': None,
            'description': '',
            'industry': [default_industry],
            'salary_min': None,
            'salary_max': None,
            'salary_type': 'Annual',
            'location': '',
            'work_type': 'Full-time',
            'employment_type': 'Permanent',
            'duration_months': None,
            'urgency_level': 'Normal',
            'status': 'Active',
            'start_date': None,
            'end_date': None
        }

def render():
    # Add custom CSS for form fields
    st.markdown("""
        <style>
        /* Base form input styling */
        .stTextInput input, .stTextArea textarea, .stSelectbox, .stMultiSelect {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
            margin-bottom: 1rem;
        }

        /* Form field focus states */
        .stTextInput input:focus, .stTextArea textarea:focus {
            border-color: #0078FF;
            box-shadow: 0 0 0 1px #0078FF;
        }

        /* Required field indicator */
        .required-field::after {
            content: " *";
            color: red;
        }

        /* Form sections */
        .form-section {
            background-color: #f8f9fa;
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
        }
        </style>
    """, unsafe_allow_html=True)

    st.title("Job Management")

    # Initialize session state
    init_session_state()
    db = Database()

    # Add new job form
    with st.expander("Add New Job", expanded=True):
        with st.form("new_job"):
            # Basic Information Section
            st.subheader("Basic Information")
            col1, col2 = st.columns(2)
            with col1:
                title = st.text_input("Job Title*", value=st.session_state.job_form['title'])

                clients = db.execute("SELECT id, name, company FROM clients WHERE status = 'Active'")
                client_id = st.selectbox(
                    "Client*",
                    options=[c['id'] for c in clients] if clients else [],
                    format_func=lambda x: next((f"{c['name']} ({c['company']})" for c in clients if c['id'] == x), ''),
                    index=0 if clients else None
                )

            with col2:
                status = st.selectbox(
                    "Status*",
                    ["Active", "Inactive"],
                    index=0
                )
                urgency_level = st.selectbox(
                    "Urgency Level",
                    ["Low", "Normal", "High", "Critical"],
                    index=1
                )

            description = st.text_area("Job Description*", value=st.session_state.job_form['description'])

            # Skills and Experience Section
            st.subheader("Skills and Experience")
            col1, col2 = st.columns(2)
            with col1:
                industry = st.multiselect(
                    "Industry*",
                    VALID_INDUSTRIES,
                    default=st.session_state.job_form['industry']
                )

            # Employment Details Section
            st.subheader("Employment Details")
            col1, col2, col3 = st.columns(3)
            with col1:
                work_type = st.selectbox(
                    "Work Type",
                    ["Full-time", "Part-time", "Contract", "Temporary"],
                    index=0
                )
            with col2:
                employment_type = st.selectbox(
                    "Employment Type",
                    ["Permanent", "Fixed-term", "Temporary", "Freelance"],
                    index=0
                )
            with col3:
                duration_months = st.number_input(
                    "Duration (Months)",
                    min_value=1,
                    value=st.session_state.job_form['duration_months'] or 1,
                    help="Required for temporary or contract positions"
                )

            # Salary Information
            st.subheader("Salary Information")
            col1, col2, col3 = st.columns(3)
            with col1:
                salary_min = st.number_input("Minimum Salary", min_value=0.0, value=st.session_state.job_form['salary_min'] or 0.0)
            with col2:
                salary_max = st.number_input("Maximum Salary", min_value=0.0, value=st.session_state.job_form['salary_max'] or 0.0)
            with col3:
                salary_type = st.selectbox(
                    "Salary Type",
                    ["Annual", "Monthly", "Weekly", "Daily", "Hourly"],
                    index=0
                )

            # Location and Dates
            st.subheader("Location and Dates")
            col1, col2, col3 = st.columns(3)
            with col1:
                location = st.text_input("Location", value=st.session_state.job_form['location'])
            with col2:
                start_date = st.date_input("Start Date", value=None)
            with col3:
                end_date = st.date_input("End Date", value=None)

            # Candidate Assignment Section
            st.subheader("Initial Candidate Assignment")
            candidates = db.execute("""
                SELECT c.id, c.name, c.email, c.industry, c.status 
                FROM candidates c 
                WHERE c.status = 'Active'
                ORDER BY c.name ASC
            """)

            selected_candidates = st.multiselect(
                "Assign Initial Candidates (Optional)",
                options=[c['id'] for c in candidates] if candidates else [],
                format_func=lambda x: next((f"{c['name']} ({c['email']}) - {c['status']}" for c in candidates if c['id'] == x), ''),
                help="You can assign candidates now or later"
            )

            if st.form_submit_button("Add Job"):
                if not all([title, client_id, description, industry]):
                    st.error("All fields marked with * are required!")
                else:
                    try:
                        # Insert new job
                        job_data = {
                            'title': title,
                            'client_id': client_id,
                            'description': description,
                            'industry': industry,
                            'salary_min': salary_min,
                            'salary_max': salary_max,
                            'salary_type': salary_type,
                            'location': location,
                            'work_type': work_type,
                            'employment_type': employment_type,
                            'duration_months': duration_months,
                            'urgency_level': urgency_level,
                            'status': status,
                            'start_date': start_date.isoformat() if start_date else None,
                            'end_date': end_date.isoformat() if end_date else None
                        }

                        db.execute_update(
                            """
                            INSERT INTO jobs (
                                title, client_id, description, industry,
                                salary_min, salary_max, salary_type, location, work_type,
                                employment_type, duration_months, urgency_level, status,
                                start_date, end_date
                            )
                            VALUES (
                                %(title)s, %(client_id)s, %(description)s, %(industry)s::text[],
                                %(salary_min)s, %(salary_max)s, %(salary_type)s, %(location)s,
                                %(work_type)s, %(employment_type)s, %(duration_months)s,
                                %(urgency_level)s, %(status)s, %(start_date)s::date,
                                %(end_date)s::date
                            )
                            RETURNING id
                            """,
                            job_data
                        )

                        # Get the newly inserted job ID from the RETURNING clause
                        result = db.execute_update(
                            """
                            INSERT INTO jobs (
                                title, client_id, description, industry,
                                salary_min, salary_max, salary_type, location, work_type,
                                employment_type, duration_months, urgency_level, status,
                                start_date, end_date
                            )
                            VALUES (
                                %(title)s, %(client_id)s, %(description)s, %(industry)s::text[],
                                %(salary_min)s, %(salary_max)s, %(salary_type)s, %(location)s,
                                %(work_type)s, %(employment_type)s, %(duration_months)s,
                                %(urgency_level)s, %(status)s, %(start_date)s::date,
                                %(end_date)s::date
                            )
                            RETURNING id
                            """,
                            job_data
                        )
                        new_job_id = result['id']

                        # Create job assignments for selected candidates
                        for candidate_id in selected_candidates:
                            db.execute_update(
                                """
                                INSERT INTO job_assignments (job_id, candidate_id, status)
                                VALUES (%s, %s, 'Pending')
                                ON CONFLICT (job_id, candidate_id) DO NOTHING
                                """,
                                (new_job_id, candidate_id)
                            )

                        st.success("Job added successfully with candidate assignments!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error creating job: {str(e)}")

    # View and manage existing jobs
    st.subheader("Existing Jobs")

    # Search and filters
    st.markdown("""
        <style>
        .search-container {
            background-color: #f8f9fa;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
        }
        </style>
    """, unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="search-container">', unsafe_allow_html=True)
        search_term = st.text_input("🔍 Search jobs", placeholder="Search by job title, client, company, or location...", 
                                  help="Enter keywords to search across jobs")
        
        col1, col2 = st.columns([1, 1])
        with col1:
            status_filter = st.multiselect("📊 Filter by Status", 
                                         ["Active", "On Hold", "Filled", "Cancelled"],
                                         placeholder="Select status...")
        with col2:
            industry_filter = st.multiselect("🏢 Filter by Industry", 
                                           VALID_INDUSTRIES,
                                           placeholder="Select industry...")
        st.markdown('</div>', unsafe_allow_html=True)

    # Build query
    query = """
        SELECT 
            j.id,
            j.title,
            j.description,
            j.industry,
            j.salary_min,
            j.salary_max,
            j.salary_type,
            j.location,
            j.work_type,
            j.employment_type,
            j.duration_months,
            j.urgency_level,
            j.status,
            j.start_date,
            j.end_date,
            c.name as client_name,
            c.company as client_company,
            STRING_AGG(DISTINCT cd.name, ', ') as candidate_names
        FROM jobs j
        JOIN clients c ON j.client_id = c.id
        LEFT JOIN job_assignments ja ON j.id = ja.job_id
        LEFT JOIN candidates cd ON ja.candidate_id = cd.id
    """

    where_conditions = []
    params = []

    if search_term:
        where_conditions.append("""
            (j.title ILIKE %s 
            OR c.name ILIKE %s 
            OR c.company ILIKE %s
            OR j.location ILIKE %s)
        """)
        search_pattern = f"%{search_term}%"
        params.extend([search_pattern] * 4)

    if status_filter:
        placeholders = ','.join(['%s'] * len(status_filter))
        where_conditions.append(f"j.status IN ({placeholders})")
        params.extend(status_filter)

    if industry_filter:
        industry_condition = """
            EXISTS (
                SELECT 1 
                FROM unnest(j.industry) AS ind 
                WHERE ind = ANY(%s)
            )
        """
        where_conditions.append(industry_condition)
        params.append(industry_filter)

    if where_conditions:
        query += " WHERE " + " AND ".join(where_conditions)

    query += " GROUP BY j.id, c.name, c.company ORDER BY j.created_at DESC"

    jobs = db.execute(query, params)

    if jobs:
        df = pd.DataFrame(jobs)

        # Format salary and experience years
        if 'salary_min' in df.columns and 'salary_max' in df.columns:
            df['salary_range'] = df.apply(lambda x: f"{x['salary_min']:,.2f} - {x['salary_max']:,.2f} ({x['salary_type']})" if pd.notnull(x['salary_min']) and pd.notnull(x['salary_max']) else "", axis=1)


        st.dataframe(
            df,
            column_config={
                "id": st.column_config.NumberColumn("ID", width="small"),
                "title": st.column_config.TextColumn("Title", width="medium"),
                "client_name": st.column_config.TextColumn("Client", width="medium"),
                "client_company": st.column_config.TextColumn("Company", width="medium"),
                "location": st.column_config.TextColumn("Location", width="medium"),
                "work_type": st.column_config.TextColumn("Work Type", width="small"),
                "employment_type": st.column_config.TextColumn("Employment", width="small"),
                "salary_range": st.column_config.TextColumn("Salary Range", width="medium"),
                "status": st.column_config.TextColumn("Status", width="small"),
                "urgency_level": st.column_config.TextColumn("Urgency", width="small"),
                "assigned_candidates": st.column_config.NumberColumn("# Assigned", width="small"),
                "candidate_names": st.column_config.TextColumn("Assigned Candidates", width="large"),
            },
            hide_index=True,
            use_container_width=True
        )
    else:
        st.info("No jobs found")

    # Candidate Assignment Section (Remains largely unchanged)
    st.write("---")
    st.write("📋 Assign Candidates")

    # Check if user has permission to assign candidates
    auth = Auth()
    if not auth.can_assign_candidates(st.session_state.user['id']):
        st.error("🚫 You don't have permission to assign candidates. This feature is restricted to administrators.")
        return

    # Get all jobs for assignment
    jobs_for_assignment = db.execute("""
        SELECT j.id, j.title, c.name as client_name 
        FROM jobs j
        JOIN clients c ON j.client_id = c.id
        WHERE j.status = 'Active'
        ORDER BY j.title
    """)

    if jobs_for_assignment:
        selected_job = st.selectbox(
            "Select Job for Assignment",
            options=jobs_for_assignment,
            format_func=lambda x: f"{x['title']} ({x['client_name']})"
        )

        if selected_job:
            # Show current assignments
            current_assignments = db.execute("""
                SELECT 
                    c.name as candidate_name,
                    ja.assigned_at
                FROM job_assignments ja
                JOIN candidates c ON ja.candidate_id = c.id
                WHERE ja.job_id = %s
                ORDER BY ja.assigned_at DESC
            """, (selected_job['id'],))

            if current_assignments:
                st.write("Current Assignments:")
                df_assignments = pd.DataFrame(current_assignments)
                st.dataframe(
                    df_assignments,
                    column_config={
                        "candidate_name": st.column_config.TextColumn("Candidate", width="medium"),
                        "assigned_at": st.column_config.DatetimeColumn("Assigned At", width="medium"),
                    },
                    hide_index=True,
                    use_container_width=True
                )

            # Assign new candidate
            if candidates:
                with st.form(f"assign_candidate_{selected_job['id']}"):
                    selected_candidate = st.selectbox(
                        "Select Candidate to Assign",
                        options=candidates,
                        format_func=lambda x: x['name']
                    )

                    if st.form_submit_button("Assign Candidate"):
                        try:
                            # Update job status to Active when candidate is assigned
                            db.execute_update("""
                                WITH job_update AS (
                                    UPDATE jobs 
                                    SET status = 'Active'
                                    WHERE id = %s
                                )
                                INSERT INTO job_assignments (job_id, candidate_id, status)
                                VALUES (%s, %s, 'Active')
                                ON CONFLICT (job_id, candidate_id) 
                                DO UPDATE SET status = 'Active'
                            """, (selected_job['id'], selected_job['id'], selected_candidate['id']))
                            st.success(f"Successfully assigned {selected_candidate['name']} to the job!")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Error assigning candidate: {str(e)}")

    # Update job status (mostly unchanged)
    with st.expander("Update Job Status"):
        all_jobs = db.execute("""
            SELECT j.id, j.title, 
                   COUNT(ja.id) as assigned_candidates
            FROM jobs j
            LEFT JOIN job_assignments ja ON j.id = ja.job_id
            GROUP BY j.id, j.title
        """)

        if all_jobs:
            selected_job = st.selectbox(
                "Select Job",
                options=all_jobs,
                format_func=lambda x: x['title'],
                key="update_job_status"
            )

            new_status = st.selectbox(
                "New Status",
                ["Active", "Inactive"]
            )

            # Get current assignments for the selected job
            if selected_job:
                current_assignments = db.execute("""
                    SELECT c.name, ja.status
                    FROM job_assignments ja
                    JOIN candidates c ON ja.candidate_id = c.id
                    WHERE ja.job_id = %s
                """, (selected_job['id'],))

                if current_assignments:
                    st.write("Current Assignments:")
                    for assignment in current_assignments:
                        st.write(f"- {assignment['name']} ({assignment['status']})")
                else:
                    st.warning("No candidates assigned to this job!")

            if st.button("Update Status"):
                # Check if job has at least one candidate assigned
                assigned_count = next((job['assigned_candidates'] for job in all_jobs if job['id'] == selected_job['id']), 0)

                if assigned_count == 0:
                    st.error("Cannot update job status. At least one candidate must be assigned to the job.")
                else:
                    db.execute_update(
                        "UPDATE jobs SET status = %s WHERE id = %s",
                        (new_status, selected_job['id'])
                    )
                    st.success("Job status updated successfully!")
                    st.rerun()


    # Delete job section (Remains largely unchanged)
    with st.expander("🗑️ Delete Job"):
        auth = Auth()
        if not auth.can_delete_records(st.session_state.user['id']):
            st.error("🚫 You don't have permission to delete jobs. This feature is restricted to administrators.")
        else:
            jobs_list = db.execute("SELECT id, title FROM jobs")
            if jobs_list:
                selected_job = st.selectbox(
                    "Select job to delete",
                    options=jobs_list,
                    format_func=lambda x: x['title'],
                    key="delete_job"
                )

                col1, col2 = st.columns([1, 1])
                with col1:
                    if st.button("Delete Job", type="primary"):
                        st.session_state['confirm_delete_job'] = True
                        st.session_state['job_to_delete'] = selected_job['id']

                # Show confirmation dialog
                if st.session_state.get('confirm_delete_job', False):
                    with col2:
                        st.error("Are you sure you want to delete this job?")
                        if st.button("Yes, Delete"):
                            try:
                                db.execute_update(
                                    "DELETE FROM jobs WHERE id = %s",
                                    (st.session_state['job_to_delete'],)
                                )
                                db.commit()
                                st.success("✅ Job deleted successfully!")
                                del st.session_state['confirm_delete_job']
                                del st.session_state['job_to_delete']
                                st.rerun()
                            except Exception as e:
                                st.error(f"🚫 Error deleting job: {str(e)}")
                        if st.button("Cancel"):
                            del st.session_state['confirm_delete_job']
                            del st.session_state['job_to_delete']
                            st.rerun()
            else:
                st.info("No jobs available")
    # Delete assigned candidate section (Remains largely unchanged)
    with st.expander("🗑️ Delete Assigned Candidate"):
        auth = Auth()
        if not auth.check_delete_permission(st.session_state.user['id']):
            st.error("🚫 Only administrators can remove assigned candidates")
        else:
            # First, get all jobs that have assignments
            jobs_with_assignments = db.execute("""
                SELECT DISTINCT j.id, j.title
                FROM jobs j
                JOIN job_assignments ja ON j.id = ja.job_id
                ORDER BY j.title
            """)

            if jobs_with_assignments:
                # Select job first
                selected_job_for_removal = st.selectbox(
                    "Select Job",
                    options=jobs_with_assignments,
                    format_func=lambda x: x['title'],
                    key="remove_assignment_job"
                )

                if selected_job_for_removal:
                    # Get assigned candidates for the selected job
                    assigned_candidates = db.execute("""
                        SELECT c.id, c.name, c.email
                        FROM candidates c
                        JOIN job_assignments ja ON c.id = ja.candidate_id
                        WHERE ja.job_id = %s
                        ORDER BY c.name
                    """, (selected_job_for_removal['id'],))

                    if assigned_candidates:
                        selected_candidate = st.selectbox(
                            "Select candidate to remove from job",
                            options=assigned_candidates,
                            format_func=lambda x: f"{x['name']} ({x['email']})",
                            key="remove_assignment_candidate"
                        )

                        col1, col2 = st.columns([1, 1])
                        with col1:
                            if st.button("Remove Candidate from Job", type="primary"):
                                st.session_state['confirm_remove_candidate'] = True
                                st.session_state['candidate_to_remove'] = {
                                    'job_id': selected_job_for_removal['id'],
                                    'candidate_id': selected_candidate['id']
                                }

                        # Show confirmation dialog
                        if st.session_state.get('confirm_remove_candidate', False):
                            with col2:
                                st.error(f"Are you sure you want to remove {selected_candidate['name']} from this job?")
                                if st.button("Yes, Remove"):
                                    try:
                                        # Delete the job assignment
                                        db.execute_update(
                                            "DELETE FROM job_assignments WHERE job_id = %s AND candidate_id = %s",
                                            (st.session_state['candidate_to_remove']['job_id'], 
                                             st.session_state['candidate_to_remove']['candidate_id'])
                                        )
                                        db.commit()
                                        st.success("✅ Candidate removed from job successfully!")
                                        del st.session_state['confirm_remove_candidate']
                                        del st.session_state['candidate_to_remove']
                                        st.rerun()
                                    except Exception as e:
                                        st.error(f"🚫 Error removing candidate from job: {str(e)}")
                                if st.button("Cancel"):
                                    del st.session_state['confirm_remove_candidate']
                                    del st.session_state['candidate_to_remove']
                                    st.rerun()
                    else:
                        st.info("No candidates assigned to this job")
            else:
                st.info("No jobs with assigned candidates available")