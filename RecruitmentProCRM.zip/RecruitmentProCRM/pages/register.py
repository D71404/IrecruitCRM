import streamlit as st
import re
from models.auth import Auth

def render():
    st.title("Register")
    
    _, col2, _ = st.columns([1,2,1])
    
    with col2:
        st.markdown('''
            <div style="padding: 2rem; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); background-color: white;">
        ''', unsafe_allow_html=True)
        
        with st.form("register_form"):
            username = st.text_input("Username*")
            email = st.text_input("Email*")
            password = st.text_input("Password*", type="password")
            confirm_password = st.text_input("Confirm Password*", type="password")
            submit = st.form_submit_button("Register", use_container_width=True)
            
            if submit:
                if not all([username, email, password, confirm_password]):
                    st.error("All fields are required")
                elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                    st.error("Please enter a valid email address")
                elif password != confirm_password:
                    st.error("Passwords do not match")
                elif len(password) < 6:
                    st.error("Password must be at least 6 characters long")
                else:
                    try:
                        auth = Auth()
                        auth.register_user(username, email, password)
                        st.success("Registration successful! Please login.")
                        st.session_state.show_register = False
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Login link
        if st.button("Already have an account? Login here"):
            st.session_state.show_register = False
            st.rerun()
