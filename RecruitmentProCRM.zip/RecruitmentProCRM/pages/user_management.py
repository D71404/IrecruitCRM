import streamlit as st
from models.auth import Auth
from models.database import Database

def render():
    st.title("👤 User Management")
    db = Database()
    
    # Only allow admin access
    auth = Auth()
    if not auth.check_permission(st.session_state.user['id'], 'admin'):
        st.error("Access denied. Only administrators can access this page.")
        return
    
    # Add new user form with enhanced styling
    with st.expander("➕ Add New User"):
        st.markdown('''
            <div class="stCard">
        ''', unsafe_allow_html=True)
        
        with st.form("new_user", clear_on_submit=True):
            col1, col2 = st.columns(2)
            with col1:
                username = st.text_input("Username*", help="Required field")
                email = st.text_input("Email*", help="Required field")
            with col2:
                password = st.text_input("Password*", type="password", help="Required field")
                role = st.selectbox("Role*", ["user", "admin"], help="Required field")
            
            submit_button = st.form_submit_button("Add User", use_container_width=True)
            if submit_button:
                try:
                    if not all([username, email, password]):
                        st.error("🚫 All fields are required!")
                    else:
                        auth.register_user(username, email, password, role)
                        st.success("✅ User added successfully!")
                        st.rerun()
                except Exception as e:
                    st.error(f"🚫 Error adding user: {str(e)}")
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Change Password Form
    with st.expander("🔑 Change User Password"):
        st.markdown('''
            <div class="stCard">
        ''', unsafe_allow_html=True)
        
        with st.form("change_password", clear_on_submit=True):
            users = auth.get_all_users()
            if users:
                user_options = {f"{user['username']} ({user['email']})": user['id'] 
                              for user in users}
                selected_user = st.selectbox(
                    "Select User*",
                    options=list(user_options.keys()),
                    help="Required field"
                )
                current_password = st.text_input(
                    "Current Password*", 
                    type="password",
                    help="Required field"
                )
                new_password = st.text_input(
                    "New Password*",
                    type="password",
                    help="Required field"
                )
                confirm_password = st.text_input(
                    "Confirm New Password*",
                    type="password",
                    help="Required field"
                )
                
                submit_button = st.form_submit_button(
                    "Change Password",
                    use_container_width=True
                )
                
                if submit_button:
                    try:
                        if not all([current_password, new_password, confirm_password]):
                            st.error("🚫 All fields are required!")
                        elif new_password != confirm_password:
                            st.error("🚫 New passwords do not match!")
                        else:
                            user_id = user_options[selected_user]
                            auth.change_password(user_id, current_password, new_password)
                            st.success("✅ Password changed successfully!")
                            st.rerun()
                    except Exception as e:
                        st.error(f"🚫 Error changing password: {str(e)}")
            else:
                st.info("No users available")
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Modify User Role
    with st.expander("👑 Modify User Role"):
        st.markdown('''
            <div class="stCard">
        ''', unsafe_allow_html=True)
        
        with st.form("modify_role", clear_on_submit=True):
            users = auth.get_all_users()
            if users:
                user_options = {f"{user['username']} ({user['email']})": user['id'] 
                              for user in users}
                selected_user = st.selectbox(
                    "Select User*",
                    options=list(user_options.keys()),
                    help="Required field"
                )
                
                # Get current role for the selected user
                current_user = next(
                    user for user in users 
                    if f"{user['username']} ({user['email']})" == selected_user
                )
                
                new_role = st.selectbox(
                    "New Role*",
                    ["user", "admin"],
                    index=0 if current_user['role'] == 'user' else 1,
                    help="Required field"
                )
                
                submit_button = st.form_submit_button(
                    "Update Role",
                    use_container_width=True
                )
                
                if submit_button:
                    try:
                        user_id = user_options[selected_user]
                        # Add selected user to session state to maintain selection after rerun
                        st.session_state['selected_user_for_role'] = selected_user
                        if auth.update_role(user_id, new_role):
                            st.success("✅ Role updated successfully!")
                            # Update the current user's role if they changed their own role
                            if user_id == st.session_state.user.get('id'):
                                st.session_state.user['role'] = new_role
                            # Clear all caches
                            for key in st.session_state.keys():
                                if isinstance(st.session_state[key], dict) and 'hash' in st.session_state[key]:
                                    del st.session_state[key]
                            # Force refresh the page
                            st.rerun()
                        else:
                            st.error("Failed to update role")
                    except Exception as e:
                        st.error(f"🚫 Error updating role: {str(e)}")
                        st.write(f"Debug info: user_id={user_id}, new_role={new_role}")
            else:
                st.info("No users available")
        
        st.markdown('</div>', unsafe_allow_html=True)
    # List existing users with delete option
    st.subheader("Existing Users")
    try:
        users = auth.get_all_users()
        if users:
            import pandas as pd
            
            # Create DataFrame with only necessary fields
            df = pd.DataFrame([
                {
                    'id': user['id'],
                    'username': user['username'],
                    'email': user['email'],
                    'role': user['role'],
                    'created_at': user['created_at']
                }
                for user in users
            ])
            
            # Convert timestamp to datetime before displaying
            df['created_at'] = pd.to_datetime(df['created_at'], unit='ms').dt.strftime('%Y-%m-%d %H:%M:%S')
            
            # Get stored passwords for admin view
            stored_passwords = {}
            if auth.check_permission(st.session_state.user['id'], 'admin'):
                stored_passwords_result = db.execute("""
                    SELECT u.id as user_id, sp.password 
                    FROM users u
                    LEFT JOIN stored_passwords sp ON u.id = sp.user_id
                """)
                stored_passwords = {row['user_id']: row['password'] for row in stored_passwords_result if row['password']}

            # Add passwords to dataframe if admin
            if auth.check_permission(st.session_state.user['id'], 'admin'):
                df['stored_password'] = df['id'].map(lambda x: stored_passwords.get(x))
            
            # Create column configurations
            column_config = {
                "username": st.column_config.TextColumn("Username", width="medium"),
                "email": st.column_config.TextColumn("Email", width="medium"),
                "role": st.column_config.TextColumn("Role", width="small"),
                "created_at": st.column_config.TextColumn("Created At", width="medium"),
            }
            
            # Add password column for admins
            if auth.check_permission(st.session_state.user['id'], 'admin'):
                # Add stored passwords to dataframe
                df['stored_password'] = df['id'].map(lambda x: '••••••••')
                
                column_config["stored_password"] = st.column_config.TextColumn(
                    "Password",
                    width="medium"
                )
                
                # Remove any password hash columns
                columns_to_drop = ['password', 'password_hash']
                df = df.drop([col for col in columns_to_drop if col in df.columns], axis=1)
            
            # Display the dataframe
            st.dataframe(
                df,
                column_config=column_config,
                hide_index=True,
                use_container_width=True
            )
            
            # Delete user section
            st.subheader("Delete User")
            col1, col2 = st.columns([3, 1])
            with col1:
                user_to_delete = st.selectbox(
                    "Select user to delete",
                    options=[f"{user['username']} ({user['email']})" for user in users],
                    key="delete_user"
                )
            with col2:
                if st.button("🗑️ Delete User", type="primary", use_container_width=True):
                    try:
                        # Get user ID from selection
                        user_id = next(
                            user['id'] for user in users 
                            if f"{user['username']} ({user['email']})" == user_to_delete
                        )
                        
                        # Prevent deleting the last admin user
                        admin_count = sum(1 for user in users if user['role'] == 'admin')
                        selected_user = next(
                            user for user in users 
                            if f"{user['username']} ({user['email']})" == user_to_delete
                        )
                        
                        if admin_count <= 1 and selected_user['role'] == 'admin':
                            st.error("🚫 Cannot delete the last admin user!")
                        else:
                            auth.delete_user(user_id)
                            st.success("✅ User deleted successfully!")
                            st.rerun()
                    except Exception as e:
                        st.error(f"🚫 Error deleting user: {str(e)}")
        else:
            st.info("No users found")
    except Exception as e:
        st.error(f"Error retrieving users: {str(e)}")
