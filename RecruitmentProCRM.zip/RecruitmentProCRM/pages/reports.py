import streamlit as st
from models.database import Database
from models.auth import Auth
import pandas as pd
from datetime import datetime
import json

def render():
    # Add custom CSS for form fields and cards
    st.markdown("""
        <style>
        /* Form input styling */
        .stTextInput input, .stTextArea textarea, .stSelectbox select {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
        }

        /* Form field hover state */
        .stTextInput input:hover, .stTextArea textarea:hover, .stSelectbox select:hover {
            border-color: #888888;
        }

        /* Form field focus state */
        .stTextInput input:focus, .stTextArea textarea:focus, .stSelectbox select:focus {
            border-color: #0078FF;
            box-shadow: 0 0 0 1px #0078FF;
        }

        /* Date input styling */
        .stDateInput input {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
        }

        /* Card styling */
        .stCard {
            padding: 1rem;
            border-radius: 0.5rem;
            margin: 1rem 0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
            background-color: #ffffff;
        }
        </style>
    """, unsafe_allow_html=True)

    st.title("📊 Reports & Analytics")

    # Only allow admin access
    auth = Auth()
    if not auth.check_permission(st.session_state.user['id'], 'admin'):
        st.error("🚫 Access denied. Only administrators can access this page.")
        return

    db = Database()

    # Export Options with enhanced UI
    st.markdown('<div class="stCard">', unsafe_allow_html=True)
    st.subheader("📥 Export Reports")
    export_options = st.multiselect(
        "Select reports to export",
        ["Total Candidates", "Distribution of Clients with Value", 
         "Distribution Industry Wise", "Active/Inactive Clients", "Active/Inactive Candidates", 
         "Total Jobs Industry Wise", "Active/Inactive Jobs"]
    )

    if st.button("Generate Report") and export_options:
        try:
            # Create a dictionary to store DataFrames
            export_data = {}

            

            if "Total Candidates" in export_options:
                try:
                    total_candidates = db.execute("""
                        WITH profile_distribution AS (
                            SELECT profile_type, COUNT(*) as count
                            FROM candidates
                            GROUP BY profile_type
                        ),
                        source_distribution AS (
                            SELECT COALESCE(source_type, 'Not Specified') as source_type, COUNT(*) as count
                            FROM candidates
                            GROUP BY source_type
                        ),
                        status_distribution AS (
                            SELECT status, COUNT(*) as count
                            FROM candidates
                            GROUP BY status
                        ),
                        base_metrics AS (
                            SELECT 
                                COUNT(*) as total_candidates,
                                MIN(created_at) as earliest_created,
                                MAX(created_at) as latest_created
                            FROM candidates
                        ),
                        monthly_trends AS (
                            SELECT 
                                DATE_TRUNC('month', created_at) as month,
                                COUNT(*) as new_candidates,
                                COUNT(*) FILTER (WHERE status = 'Active') as active_candidates,
                                COUNT(*) FILTER (WHERE status = 'Inactive') as inactive_candidates
                            FROM candidates
                            GROUP BY month
                            ORDER BY month DESC
                            LIMIT 12
                        )
                        SELECT 
                            bm.total_candidates,
                            jsonb_object_agg(pd.profile_type, pd.count) as profile_distribution,
                            jsonb_object_agg(sd.source_type, sd.count) as source_distribution,
                            jsonb_object_agg(std.status, std.count) as status_distribution,
                            bm.earliest_created,
                            bm.latest_created,
                            ROUND(
                                CAST(
                                    (SUM(CASE WHEN c.status = 'Active' THEN 1 ELSE 0 END)::numeric / 
                                     COUNT(*)::numeric * 100)
                                AS numeric),
                                2
                            ) as active_percentage,
                            jsonb_object_agg(
                                mt.month::date::text,
                                jsonb_build_object(
                                    'new', mt.new_candidates,
                                    'active', mt.active_candidates,
                                    'inactive', mt.inactive_candidates
                                )
                            ) as monthly_stats
                        FROM candidates c
                        CROSS JOIN base_metrics bm
                        LEFT JOIN profile_distribution pd ON true
                        LEFT JOIN source_distribution sd ON true
                        LEFT JOIN status_distribution std ON true
                        CROSS JOIN monthly_trends mt
                        GROUP BY 
                            bm.total_candidates,
                            bm.earliest_created,
                            bm.latest_created
                    """)

                    if total_candidates:
                        df = pd.DataFrame(total_candidates)

                        # Format date columns
                        date_cols = ['earliest_created', 'latest_created']
                        for col in date_cols:
                            if col in df.columns:
                                df[col] = pd.to_datetime(df[col]).dt.strftime('%Y-%m-%d %H:%M:%S')

                        # Convert JSON columns to readable format
                        json_cols = ['profile_distribution', 'source_distribution', 'status_distribution', 'monthly_stats']
                        for col in json_cols:
                            if col in df.columns and df[col].notna().any():
                                df[col] = df[col].apply(lambda x: json.dumps(x, indent=2) if x else '')

                        # Add summary statistics
                        df['avg_monthly_candidates'] = df['monthly_stats'].apply(
                            lambda x: sum(v.get('new', 0) for v in json.loads(x).values()) / 12 if x else 0
                        )

                        export_data['total_candidates'] = df
                except Exception as e:
                    st.error(f"Error generating Total Candidates report: {str(e)}")
                    db.rollback()

            if "Distribution of Clients with Value" in export_options:
                try:
                    # Add time period selector for value metrics visualization
                    time_period = st.selectbox(
                        "Select Time Period for Value Metrics",
                        ["Weekly", "Half-Monthly", "Monthly", "Quarterly"],
                        key="value_metrics_period"
                    )

                    # Get time-based value metrics
                    period_query = {
                        "Weekly": """
                            SELECT 
                                date_trunc('week', created_at) as period,
                                SUM(value) as total_value,
                                COUNT(*) as client_count
                            FROM clients
                            WHERE created_at >= CURRENT_DATE - INTERVAL '12 weeks'
                            GROUP BY date_trunc('week', created_at)
                            ORDER BY period
                        """,
                        "Half-Monthly": """
                            SELECT 
                                CASE 
                                    WHEN EXTRACT(DAY FROM created_at) <= 15 
                                    THEN date_trunc('month', created_at)
                                    ELSE date_trunc('month', created_at) + INTERVAL '15 days'
                                END as period,
                                SUM(value) as total_value,
                                COUNT(*) as client_count
                            FROM clients
                            WHERE created_at >= CURRENT_DATE - INTERVAL '6 months'
                            GROUP BY 
                                CASE 
                                    WHEN EXTRACT(DAY FROM created_at) <= 15 
                                    THEN date_trunc('month', created_at)
                                    ELSE date_trunc('month', created_at) + INTERVAL '15 days'
                                END
                            ORDER BY period
                        """,
                        "Monthly": """
                            SELECT 
                                date_trunc('month', created_at) as period,
                                SUM(value) as total_value,
                                COUNT(*) as client_count
                            FROM clients
                            WHERE created_at >= CURRENT_DATE - INTERVAL '12 months'
                            GROUP BY date_trunc('month', created_at)
                            ORDER BY period
                        """,
                        "Quarterly": """
                            SELECT 
                                date_trunc('quarter', created_at) as period,
                                SUM(value) as total_value,
                                COUNT(*) as client_count
                            FROM clients
                            WHERE created_at >= CURRENT_DATE - INTERVAL '4 quarters'
                            GROUP BY date_trunc('quarter', created_at)
                            ORDER BY period
                        """
                    }

                    timeline_data = db.execute(period_query[time_period])

                    if timeline_data:
                        df_timeline = pd.DataFrame(timeline_data)

                        # Create timeline visualization
                        import plotly.graph_objects as go
                        from plotly.subplots import make_subplots

                        # Create two columns for the charts
                        chart_col1, chart_col2 = st.columns([1, 1])

                        # Combined chart (line + bar)
                        fig = make_subplots(specs=[[{"secondary_y": True}]])

                        # Add value line
                        fig.add_trace(
                            go.Scatter(
                                x=df_timeline['period'],
                                y=df_timeline['total_value'],
                                name="Total Value",
                                line=dict(color="#22c55e", width=2),
                                hovertemplate="Value: £%{y:,.2f}<br>Period: %{x}<extra></extra>"
                            ),
                            secondary_y=False
                        )

                        # Add client count bars
                        fig.add_trace(
                            go.Bar(
                                x=df_timeline['period'],
                                y=df_timeline['client_count'],
                                name="Client Count",
                                marker_color="#3b82f6",
                                hovertemplate="Clients: %{y}<br>Period: %{x}<extra></extra>"
                            ),
                            secondary_y=True
                        )

                        # Update layout
                        fig.update_layout(
                            title=f"{time_period} Client Value Metrics",
                            hovermode="x unified",
                            showlegend=True,
                            height=400,
                            margin=dict(t=40, b=40, l=50, r=50),
                            title_x=0.5,
                            plot_bgcolor='white',
                            paper_bgcolor='white',
                            font=dict(size=12)
                        )

                        # Update axes
                        fig.update_yaxes(title_text="Total Value (£)", secondary_y=False, tickformat=",.0f")
                        fig.update_yaxes(title_text="Number of Clients", secondary_y=True)

                        with chart_col1:
                            st.plotly_chart(fig, use_container_width=True)

                        # Value trend line chart
                        fig_line = go.Figure()

                        fig_line.add_trace(
                            go.Scatter(
                                x=df_timeline['period'],
                                y=df_timeline['total_value'],
                                name="Total Value",
                                line=dict(color="#22c55e", width=2),
                                hovertemplate="Value: £%{y:,.2f}<br>Period: %{x}<extra></extra>"
                            )
                        )

                        fig_line.update_layout(
                            title=f"{time_period} Value Trend",
                            hovermode="x unified",
                            showlegend=True,
                            height=400,
                            margin=dict(t=40, b=40, l=50, r=50),
                            title_x=0.5,
                            plot_bgcolor='white',
                            paper_bgcolor='white',
                            font=dict(size=12),
                            yaxis=dict(title="Total Value (£)", tickformat=",.0f"),
                            xaxis=dict(title="Period")
                        )

                        with chart_col2:
                            st.plotly_chart(fig_line, use_container_width=True)

                    # Get client value distribution data
                    client_value_data = db.execute("""
                        WITH value_ranges AS (
                            SELECT 
                                c.*,
                                CASE 
                                    WHEN value < 1000 THEN 'Under £1,000'
                                    WHEN value < 5000 THEN '£1,000 - £4,999'
                                    WHEN value < 10000 THEN '£5,000 - £9,999'
                                    WHEN value < 50000 THEN '£10,000 - £49,999'
                                    ELSE 'Over £50,000'
                                END as value_range,
                                EXTRACT(YEAR FROM created_at) as year
                            FROM clients c
                        ),
                        year_over_year AS (
                            SELECT 
                                industry,
                                year,
                                SUM(value) as total_value,
                                LAG(SUM(value)) OVER (PARTITION BY industry ORDER BY year) as prev_year_value
                            FROM value_ranges
                            GROUP BY industry, year
                        ),
                        industry_metrics AS (
                            SELECT 
                                industry,
                                value_range,
                                COUNT(*) as client_count,
                                ROUND(AVG(value)::numeric, 2) as average_value,
                                ROUND(MIN(value)::numeric, 2) as min_value,
                                ROUND(MAX(value)::numeric, 2) as max_value,
                                ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY value)::numeric, 2) as median_value
                            FROM value_ranges
                            GROUP BY industry, value_range
                        )
                        SELECT 
                            im.*,
                            yoy.total_value,
                            yoy.prev_year_value,
                            CASE 
                                WHEN yoy.prev_year_value > 0 
                                THEN ROUND(((yoy.total_value - yoy.prev_year_value) / yoy.prev_year_value * 100)::numeric, 2)
                                ELSE NULL
                            END as yoy_growth_percentage
                        FROM industry_metrics im
                        LEFT JOIN year_over_year yoy ON im.industry = yoy.industry
                        ORDER BY 
                            im.industry,
                            CASE im.value_range
                                WHEN 'Under £1,000' THEN 1
                                WHEN '£1,000 - £4,999' THEN 2
                                WHEN '£5,000 - £9,999' THEN 3
                                WHEN '£10,000 - £49,999' THEN 4
                                WHEN 'Over £50,000' THEN 5
                            END
                    """)

                    if client_value_data:
                        df = pd.DataFrame(client_value_data)

                        # Format monetary values
                        monetary_columns = ['average_value', 'min_value', 'max_value', 'median_value', 'total_value', 'prev_year_value']
                        for col in monetary_columns:
                            if col in df.columns:
                                df[col] = df[col].apply(lambda x: f"£{x:,.2f}" if pd.notna(x) else '')

                        # Format percentages
                        if 'yoy_growth_percentage' in df.columns:
                            df['yoy_growth_percentage'] = df['yoy_growth_percentage'].apply(
                                lambda x: f"{x:+.2f}%" if pd.notna(x) else 'N/A'
                            )

                        export_data['client_value_distribution'] = df
                except Exception as e:
                    st.error(f"Error generating Client Value Distribution report: {str(e)}")
                    db.rollback()
                if client_value_data:
                    export_data['client_value_distribution'] = df

            if "Distribution Industry Wise" in export_options:
                industry_data = db.execute("""
                    WITH industry_counts AS (
                        SELECT 
                            COALESCE(i.industry_val, 'Not Specified') as industry,
                            'Candidates' as entity_type,
                            COUNT(*) as count
                        FROM candidates c
                        LEFT JOIN LATERAL unnest(c.industry) AS i(industry_val) ON true
                        GROUP BY COALESCE(i.industry_val, 'Not Specified')
                        UNION ALL
                        SELECT 
                            COALESCE(i.industry_val, 'Not Specified') as industry,
                            'Clients' as entity_type,
                            COUNT(*) as count
                        FROM clients c
                        LEFT JOIN LATERAL unnest(c.industry) AS i(industry_val) ON true
                        GROUP BY COALESCE(i.industry_val, 'Not Specified')
                        UNION ALL
                        SELECT 
                            unnest(industry) as industry,
                            'Jobs' as entity_type,
                            COUNT(*) as count
                        FROM jobs
                        WHERE industry IS NOT NULL
                        GROUP BY unnest(industry)
                    )
                    SELECT 
                        industry,
                        SUM(CASE WHEN entity_type = 'Candidates' THEN count ELSE 0 END) as candidates,
                        SUM(CASE WHEN entity_type = 'Clients' THEN count ELSE 0 END) as clients,
                        SUM(CASE WHEN entity_type = 'Jobs' THEN count ELSE 0 END) as jobs,
                        SUM(count) as total
                    FROM industry_counts
                    WHERE industry IS NOT NULL AND industry != ''
                    GROUP BY industry
                    ORDER BY total DESC
                """)
                if industry_data:
                    export_data['industry_distribution'] = pd.DataFrame(industry_data)

            if "Active/Inactive Clients" in export_options:
                client_status_data = db.execute("""
                    SELECT 
                        status,
                        COUNT(*) as count,
                        ROUND(
                            CAST(
                                (COUNT(*)::numeric / NULLIF(SUM(COUNT(*)) OVER (), 0)::numeric * 100)
                            AS numeric),
                            2
                        ) as percentage
                    FROM clients
                    GROUP BY status
                    ORDER BY count DESC
                """)
                if client_status_data:
                    export_data['client_status'] = pd.DataFrame(client_status_data)

            if "Active/Inactive Candidates" in export_options:
                candidate_status_data = db.execute("""
                    SELECT 
                        status,
                        COUNT(*) as count,
                        ROUND(
                            CAST(
                                (COUNT(*)::numeric / NULLIF(SUM(COUNT(*)) OVER (), 0)::numeric * 100)
                            AS numeric),
                            2
                        ) as percentage
                    FROM candidates
                    GROUP BY status
                    ORDER BY count DESC
                """)
                if candidate_status_data:
                    export_data['candidate_status'] = pd.DataFrame(candidate_status_data)

            if "Total Jobs Industry Wise" in export_options:
                jobs_by_industry = db.execute("""
                    SELECT 
                        industry,
                        COUNT(*) as total_jobs,
                        ROUND(
                            CAST(
                                (COUNT(*)::numeric / NULLIF(SUM(COUNT(*)) OVER (), 0)::numeric * 100)
                            AS numeric),
                            2
                        ) as percentage
                    FROM jobs
                    GROUP BY industry
                    ORDER BY total_jobs DESC
                """)
                if jobs_by_industry:
                    export_data['jobs_by_industry'] = pd.DataFrame(jobs_by_industry)

            if "Active/Inactive Jobs" in export_options:
                jobs_status_data = db.execute("""
                    SELECT 
                        status,
                        COUNT(*) as count,
                        ROUND(
                            CAST(
                                (COUNT(*)::numeric / NULLIF(SUM(COUNT(*)) OVER (), 0)::numeric * 100)
                            AS numeric),
                            2
                        ) as percentage
                    FROM jobs
                    GROUP BY status
                    ORDER BY count DESC
                """)
                if jobs_status_data:
                    export_data['jobs_status'] = pd.DataFrame(jobs_status_data)

            # Display and create download buttons for each selected report
            for name, df in export_data.items():
                st.markdown(f'<div class="stCard">', unsafe_allow_html=True)
                st.subheader(f"📊 {name.replace('_', ' ').title()}")

                # Display the dataframe with formatting
                st.dataframe(
                    df,
                    hide_index=True,
                    use_container_width=True
                )

                # Create download button
                csv = df.to_csv(index=False)
                st.download_button(
                    label=f"⬇️ Download {name.replace('_', ' ').title()}",
                    data=csv,
                    file_name=f"{name}_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime='text/csv',
                    key=f"download_{name}",
                    use_container_width=True
                )
                st.markdown('</div>', unsafe_allow_html=True)

        except Exception as e:
            st.error(f"🚫 Error generating reports: {str(e)}")
            db.rollback()