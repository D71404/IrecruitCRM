from models.auth import Auth
import streamlit as st
from models.database import Database
import pandas as pd
import re

def render():
    # Add loading placeholder
    with st.spinner("Loading Client Management..."):
        st.title("Client Management")

        # Add container for smooth transitions
        main_container = st.container()
        with main_container:
            db = Database()
            auth = Auth()

            # Check if user has permission to view client value metrics
            has_value_permission = False
            if 'user' in st.session_state and st.session_state.user:
                has_value_permission = auth.check_permission(st.session_state.user['id'], 'admin')

            # Add new client form
            with st.expander("Add New Client"):
                with st.form("new_client"):
                    name = st.text_input("Name*", help="Required field")
                    email = st.text_input("Email*", help="Required field")
                    phone = st.text_input("Phone*", help="Required field")
                    company = st.text_input("Company*", help="Required field")
                    from utils.constants import VALID_INDUSTRIES
                    industry = st.selectbox(
                        "Industry*",
                        VALID_INDUSTRIES,
                        help="Required field"
                    )
                    status = st.selectbox(
                        "Status*",
                        ["Active", "Inactive", "Lead", "Former"],
                        help="Required field"
                    )
                    value = st.number_input("Value (£)*", min_value=0.0, format="%.2f", help="Required field")

                    if st.form_submit_button("Add Client"):
                        # Validate all required fields
                        if not all([name, email, phone, company, industry, status]):
                            st.error("All fields marked with * are required!")
                        elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                            st.error("Please enter a valid email address!")
                        else:
                            try:
                                db.execute_update(
                                    """
                                    INSERT INTO clients (name, email, phone, company, industry, status, value)
                                    VALUES (%s, %s, %s, %s, %s::text[], %s, %s)
                                    """,
                                    (name, email, phone, company, [industry], status, value)
                                )
                                st.success("Client added successfully!")
                                st.rerun()
                            except Exception as e:
                                st.error(f"Error adding client: {str(e)}")

            # Search clients
            search_col1, search_col2 = st.columns([1, 3])
            with search_col1:
                search_type = st.selectbox(
                    "Search by",
                    ["All Fields", "ID", "Name", "Email"],
                    help="Select how you want to search for clients"
                )
            with search_col2:
                search_term = st.text_input("Search clients")

            if search_term:
                if search_type == "ID" and search_term.isdigit():
                    clients = db.execute("""
                        SELECT id, name, company, industry, email, phone, status, value, created_at
                        FROM clients
                        WHERE id = %s
                    """, (int(search_term),))
                elif search_type == "Name":
                    clients = db.execute("""
                        SELECT id, name, company, industry, email, phone, status, value, created_at
                        FROM clients
                        WHERE name ILIKE %s
                    """, (f"%{search_term}%",))
                elif search_type == "Email":
                    clients = db.execute("""
                        SELECT id, name, company, industry, email, phone, status, value, created_at
                        FROM clients
                        WHERE email ILIKE %s
                    """, (f"%{search_term}%",))
                else:
                    clients = db.execute("""
                        SELECT id, name, company, industry, email, phone, status, value, created_at
                        FROM clients
                        WHERE id::text = %s
                        OR name ILIKE %s
                        OR company ILIKE %s
                        OR email ILIKE %s
                        OR EXISTS (
                            SELECT 1 
                            FROM unnest(industry) AS ind 
                            WHERE ind ILIKE %s
                        )
                        OR status ILIKE %s
                    """, (search_term, f"%{search_term}%", f"%{search_term}%", 
                          f"%{search_term}%", f"%{search_term}%", f"%{search_term}%"))
            else:
                clients = db.execute("SELECT id, name, company, industry, email, phone, status, value, created_at FROM clients ORDER BY created_at DESC")

            if clients:
                df = pd.DataFrame(clients)
                # Format value column to show currency
                if 'value' in df.columns:
                    df['value'] = df['value'].apply(lambda x: f"£{x:,.2f}" if pd.notnull(x) else "")

                # Remove value column for non-admin users
                if not has_value_permission:
                    df = df.drop(columns=['value'])

                column_config = {
                    "id": st.column_config.NumberColumn("ID", width="small"),
                    "name": st.column_config.TextColumn("Name", width="medium"),
                    "company": st.column_config.TextColumn("Company", width="medium"),
                    "industry": st.column_config.TextColumn("Industry", width="medium"),
                    "status": st.column_config.TextColumn("Status", width="small"),
                    "email": st.column_config.TextColumn("Email", width="medium"),
                    "phone": st.column_config.TextColumn("Phone", width="medium"),
                    "value": st.column_config.TextColumn("Value", width="small")
                }

                if has_value_permission:
                    column_config["value"] = st.column_config.TextColumn("Value", width="small")
                else:
                    column_config.pop("value", None)


                st.dataframe(
                    df,
                    column_config=column_config,
                    hide_index=True,
                    use_container_width=True
                )
            else:
                st.info("No clients found")

            # View client details with associated jobs
            st.subheader("Client Details")
            client_list = db.execute("SELECT id, name, company FROM clients")
            if client_list:
                selected_client = st.selectbox(
                    "Select Client",
                    options=client_list,
                    format_func=lambda x: f"{x['name']} ({x['company']})"
                )

                if selected_client:
                    client_jobs = db.execute("""
                        SELECT 
                            j.id,
                            j.title,
                            j.description,
                            j.salary_min,
                            j.salary_max,
                            j.salary_type,
                            j.location,
                            j.work_type,
                            j.employment_type,
                            j.status,
                            j.urgency_level,
                            j.created_at,
                            COUNT(t.id) as timesheet_count
                        FROM jobs j
                        LEFT JOIN timesheets t ON j.id = t.job_id
                        WHERE j.client_id = %s
                        GROUP BY j.id
                        ORDER BY j.created_at DESC
                    """, (selected_client['id'],))

                    if client_jobs:
                        st.write("Active Jobs:")
                        df_jobs = pd.DataFrame(client_jobs)
                        st.dataframe(df_jobs)
                    else:
                        st.info("No jobs found for this client")

            # Update client status with enhanced styling
            with st.expander("📝 Update Client Status"):
                st.markdown('''
                    <div class="stCard">
                ''', unsafe_allow_html=True)

                try:
                    clients_list = db.execute("SELECT id, name, company FROM clients ORDER BY name")
                    if clients_list:
                        col1, col2 = st.columns(2)
                        with col1:
                            selected_client = st.selectbox(
                                "Select Client",
                                options=clients_list,
                                format_func=lambda x: f"{x['name']} ({x['company']})",
                                key="update_client"
                            )
                        with col2:
                            new_status = st.selectbox(
                                "New Status",
                                ["Active", "Inactive"]
                            )

                        if st.button("Update Status", use_container_width=True):
                            try:
                                db.execute_update(
                                    "UPDATE clients SET status = %s WHERE id = %s",
                                    (new_status, selected_client['id'])
                                )
                                st.success("✅ Status updated successfully!")
                                st.rerun()
                            except Exception as e:
                                st.error(f"🚫 Error updating status: {str(e)}")
                    else:
                        st.info("ℹ️ No clients available")
                except Exception as e:
                    st.error(f"🚫 Error loading clients: {str(e)}")

                st.markdown('</div>', unsafe_allow_html=True)

            # Delete client section
            with st.expander("🗑️ Delete Client"):
                auth = Auth()
                if not auth.check_delete_permission(st.session_state.user['id']):
                    st.error("🚫 Only administrators can delete clients")
                else:
                    clients_list = db.execute("SELECT id, name, company FROM clients")
                    if clients_list:
                        selected_client = st.selectbox(
                            "Select client to delete",
                            options=clients_list,
                            format_func=lambda x: f"{x['name']} ({x['company']})",
                            key="delete_client"
                        )

                        if st.button("Delete Client", type="primary"):
                            try:
                                # First delete associated jobs
                                db.execute_update(
                                    """
                                    DELETE FROM job_assignments 
                                    WHERE job_id IN (SELECT id FROM jobs WHERE client_id = %s)
                                    """,
                                    (selected_client['id'],)
                                )

                                # Then delete the jobs
                                db.execute_update(
                                    "DELETE FROM jobs WHERE client_id = %s",
                                    (selected_client['id'],)
                                )

                                # Finally delete the client
                                db.execute_update(
                                    "DELETE FROM clients WHERE id = %s",
                                    (selected_client['id'],)
                                )
                                db.commit()
                                st.success("✅ Client and associated jobs deleted successfully!")
                            except Exception as e:
                                st.error(f"🚫 Error deleting client: {str(e)}")
                    else:
                        st.info("No clients available")