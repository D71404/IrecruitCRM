import streamlit as st
from models.auth import Auth
from models.candidate import Candidate
from models.database import Database
import pandas as pd
import re
import json
import os
import magic
from datetime import datetime
from utils.constants import VALID_INDUSTRIES

def validate_phone(phone):
    """Validate phone number format"""
    phone_pattern = re.compile(r'^\+?1?\d{9,15}$')
    return bool(phone_pattern.match(phone.replace('-', '').replace(' ', '')))

def format_skills(skills):
    """Format skills array for display"""
    if isinstance(skills, list):
        return ", ".join(skills)
    return ""

def validate_candidate_data(row):
    """Validate candidate data from Excel"""
    errors = []
    if not row.get('name'):
        errors.append("Name is required")
    if not row.get('email') or not re.match(r"[^@]+@[^@]+\.[^@]+", str(row.get('email', ''))):
        errors.append("Valid email is required")
    if row.get('phone') and not validate_phone(str(row.get('phone', ''))):
        errors.append("Invalid phone number format")
    if not row.get('industry'):
        errors.append("Industry is required")
    return errors

def render():
    # Initialize session state for dropdowns if not exists
    if 'dropdown_options' not in st.session_state:
        st.session_state.dropdown_options = {
            'industries': VALID_INDUSTRIES,
            'status_options': ["Active", "Inactive"],
            'source_types': ["Direct Application (Website)", "Referral", "LinkedIn", "Indeed", "Other"]
        }

    st.markdown("""
        <style>
        /* Base form input styling */
        .stTextInput input, .stTextArea textarea {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
            margin-bottom: 1rem;
        }

        /* Selectbox and MultiSelect styling */
        .stSelectbox, div[data-baseweb="select"] {
            background-color: #ffffff !important;
            border: 1px solid #cccccc !important;
            border-radius: 4px !important;
            margin-bottom: 1rem !important;
            position: relative !important;
            z-index: 1 !important;
        }

        /* Dropdown container */
        div[data-baseweb="popover"] {
            background-color: #ffffff !important;
            border: 1px solid #cccccc !important;
            border-radius: 4px !important;
            z-index: 999 !important;
            position: absolute !important;
            max-height: 300px !important;
            overflow-y: auto !important;
        }

        /* Option styling */
        div[data-baseweb="select"] div[role="option"] {
            padding: 0.5rem !important;
            color: #000000 !important;
            background-color: #ffffff !important;
            cursor: pointer !important;
        }

        div[data-baseweb="select"] div[role="option"]:hover {
            background-color: #f0f0f0 !important;
        }

        /* Selected option styling */
        div[data-baseweb="tag"] {
            background-color: #e6e6e6 !important;
            border-radius: 3px !important;
            margin: 2px !important;
            padding: 2px 6px !important;
        }

        /* Fix for dropdown visibility */
        .stSelectbox > div[data-baseweb="select"] {
            position: relative !important;
            z-index: 2 !important;
        }

        /* Ensure dropdowns are clickable */
        .stSelectbox, .stMultiSelect {
            position: relative !important;
            z-index: 3 !important;
        }

        /* Form layout improvements */
        form {
            background-color: #ffffff;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        /* Make sure all form elements are visible */
        .element-container {
            position: relative !important;
        }
        </style>
    """, unsafe_allow_html=True)

    if 'user' not in st.session_state:
        st.error("Please log in to continue")
        return

    st.title("👥 Candidate Management")

    db = Database()

    # Add new candidate form
    tab1, tab2 = st.tabs(["Single Entry", "Batch Upload"])

    with tab1:
        with st.expander("➕ Add New Single Candidate"):
            with st.form("new_candidate", clear_on_submit=True):
                col1, col2 = st.columns(2)
                with col1:
                    name = st.text_input("Name*", help="Required field")
                    email = st.text_input("Email*", help="Required field")
                    cv_file = st.file_uploader("Upload CV", type=["pdf", "doc", "docx"], help="Supported formats: PDF, DOC, DOCX")

                with col2:
                    phone = st.text_input("Phone", help="Format: +1234567890 or 1234567890")

                    # Industry field with proper multiselect
                    industry = st.multiselect(
                        "Industry*",
                        options=st.session_state.dropdown_options['industries'],
                        help="Select one or more industries",
                        key="industry_select"
                    )

                    profile_type = st.selectbox(
                        "Profile Type*",
                        options=["Temp", "Perm", "Exects"],
                        help="Required field",
                        key="profile_type_select"
                    )

                    source_type = st.selectbox(
                        "Candidate Source*",
                        options=st.session_state.dropdown_options['source_types'],
                        help="Where did the candidate come from?",
                        key="source_type_select"
                    )

                    status = st.selectbox(
                        "Status*",
                        options=st.session_state.dropdown_options['status_options'],
                        index=0,
                        key="status_select"
                    )

                    source_details = None
                    if source_type == "Other":
                        source_details = st.text_input(
                            "Please specify source",
                            help="Enter details about the source"
                        )

                submit_button = st.form_submit_button("Add Candidate", use_container_width=True)

                if submit_button:
                    try:
                        if not name or not email or not industry:  
                            st.error("🚫 Name, email, and industry are required!")
                        elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                            st.error("🚫 Please enter a valid email address!")
                        elif phone and not validate_phone(phone):
                            st.error("🚫 Please enter a valid phone number!")
                        else:
                            cleaned_phone = phone.replace('-', '').replace(' ', '') if phone else None

                            # Create a new Candidate instance
                            candidate = Candidate()
                            try:
                                # Process CV file if uploaded
                                cv_file_path = None
                                cv_file_name = None

                                if cv_file is not None:
                                    upload_dir = os.path.join(os.getcwd(), "uploads")
                                    os.makedirs(upload_dir, exist_ok=True)

                                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                                    safe_filename = "".join(c for c in cv_file.name if c.isalnum() or c in ('-', '_', '.'))
                                    unique_filename = f"{timestamp}_{safe_filename}"
                                    cv_file_path = os.path.join("uploads", unique_filename)

                                    with open(cv_file_path, "wb") as f:
                                        f.write(cv_file.getbuffer())
                                    cv_file_name = cv_file.name

                                # Create the candidate
                                result = candidate.create(
                                    name=name,
                                    email=email,
                                    phone=cleaned_phone,
                                    industry=industry,
                                    profile_type=profile_type,
                                    status=status,
                                    source_type=source_type,
                                    source_details=source_details,
                                    cv_file=cv_file_path,
                                    cv_file_name=cv_file_name
                                )
                                if result:
                                    st.success(f"✅ Candidate {name} added successfully!")
                                    st.session_state.refresh_candidates = True
                                    st.rerun()
                            except Exception as e:
                                db.rollback()
                                if "duplicate key" in str(e).lower():
                                    st.error("🚫 A candidate with this email already exists!")
                                else:
                                    st.error(f"🚫 Error adding candidate: {str(e)}")
                    except ValueError as e:
                        st.error(f"🚫 Validation error: {str(e)}")

        with tab2:
            with st.expander("📤 Batch Upload Candidates"):
                st.markdown("### Batch Upload Candidates")
                st.markdown("""
                    Upload an Excel file (.xlsx) with the following columns:
                - name (required)
                - email (required)
                - phone
                - industry (required, comma-separated)
                - profile_type (Temp/Perm/Exects)
                - source_type
                - status (Active/Inactive)
            """)

                uploaded_file = st.file_uploader("Upload Excel File", type=['xlsx'], key="batch_upload")

                if uploaded_file is not None:
                    try:
                        df = pd.read_excel(uploaded_file)
                        # Convert column names to lowercase
                        df.columns = df.columns.str.lower()
                        

                        # Display the uploaded data preview
                        st.write("Preview of uploaded data:")
                        st.dataframe(df.head())

                        if st.button("Process Batch Upload"):
                            success_count = 0
                            error_count = 0
                            error_messages = []

                            progress_bar = st.progress(0)
                            status_text = st.empty()

                            candidate = Candidate()

                            for index, row in df.iterrows():
                                progress = (index + 1) / len(df)
                                progress_bar.progress(progress)
                                status_text.text(f"Processing {index + 1} of {len(df)} candidates...")

                                try:
                                    # Prepare the data
                                    industries = row.get('industry', '').split(',') if pd.notna(row.get('industry')) else []
                                    industries = [ind.strip() for ind in industries]
                                    

                                    # Create candidate entry
                                    result = candidate.create(
                                        name=str(row.get('name', '')).strip(),
                                        email=str(row.get('email', '')).strip(),
                                        phone=str(row.get('phone', '')).strip() if pd.notna(row.get('phone')) else None,
                                        industry=industries,
                                        profile_type=str(row.get('profile_type', 'Temp')).strip(),
                                        status=str(row.get('status', 'Active')).strip(),
                                        source_type=str(row.get('source_type', 'Direct Application (Website)')).strip()
                                    )
                                    

                                    if result:
                                        success_count += 1
                                except Exception as e:
                                    error_count += 1
                                    error_messages.append(f"Row {index + 1}: {str(e)}")

                                
                            # Display results
                            st.success(f"✅ Successfully added {success_count} candidates")
                            if error_count > 0:
                                with st.expander("Show Errors"):
                                    for error in error_messages:
                                        st.error(error)

                            if success_count > 0:
                                st.session_state.refresh_candidates = True
                                st.rerun()

                    except Exception as e:
                        st.error(f"Error processing file: {str(e)}")

    # Search and filter section
    st.markdown('''
        <div class="stCard hover-effect" style="margin: 1rem 0;">
    ''', unsafe_allow_html=True)

    col1, col2 = st.columns([2, 1])
    with col1:
        search_term = st.text_input(
            "🔍 Search candidates",
            placeholder="Search by name, email, industry, profile type, or status..."
        )
    with col2:
        status_filter = st.multiselect(
            "Filter by Status",
            ["Active", "Inactive"],
            placeholder="All Statuses"
        )

    try:
        # Initialize refresh state if not exists
        if 'refresh_candidates' not in st.session_state:
            st.session_state.refresh_candidates = False

        candidate_model = Candidate()
        if search_term:
            # Check if search term is a number (ID search)
            if search_term.isdigit():
                candidates = candidate_model.search_by_id(int(search_term))
            else:
                candidates = candidate_model.search(search_term)
        else:
            candidates = candidate_model.get_all()

        if candidates:
            # Convert the list of dictionaries to DataFrame
            df = pd.DataFrame(candidates)

            if 'industry' in df.columns:
                df['industry'] = df['industry'].apply(
                    lambda x: ', '.join(x) if isinstance(x, list) else 
                    ', '.join(json.loads(x)) if isinstance(x, str) and x.startswith('[') else str(x)
                )

            display_df = df.copy()

            # Select only the columns we want to display
            display_df['has_cv'] = display_df.apply(
                lambda row: '✅' if row.get('cv_file_path') else '❌', axis=1
            )
            display_columns = ['id', 'name', 'email', 'phone', 'industry', 'profile_type', 'status', 'source_type', 'has_cv']
            display_df = display_df[display_columns]

            st.dataframe(
                display_df,
                column_config={
                    "id": st.column_config.NumberColumn("ID", width="small"),
                    "name": st.column_config.TextColumn("Name", width="medium"),
                    "email": st.column_config.TextColumn("Email", width="medium"),
                    "phone": st.column_config.TextColumn("Phone", width="medium"),
                    "industry": st.column_config.TextColumn("Industry", width="large"),
                    "profile_type": st.column_config.TextColumn("Profile Type", width="small"),
                    "status": st.column_config.TextColumn("Status", width="small"),
                    "referring_candidate": st.column_config.TextColumn("Referring Candidate", width="medium"),
                    "source_type": st.column_config.TextColumn("Source Type", width="medium"),
                    "has_cv": st.column_config.TextColumn("CV", width="small")
                },
                hide_index=True,
                use_container_width=True
            )
        else:
            st.info("No candidates found")

    except Exception as e:
        st.error(f"Error retrieving candidates: {str(e)}")

    st.markdown('</div>', unsafe_allow_html=True)

    # CV Upload Section for existing candidates
    with st.expander("📄 Upload CV for Existing Candidate"):
        candidates_without_cv = db.execute("""
            SELECT id, name, email 
            FROM candidates 
            WHERE cv_file_path IS NULL 
            ORDER BY name
        """)

        if candidates_without_cv:
            selected_candidate = st.selectbox(
                "Select Candidate",
                options=candidates_without_cv,
                format_func=lambda x: f"{x['name']} ({x['email']})",
                key="cv_upload_candidate"
            )

            cv_file = st.file_uploader(
                "Upload CV",
                type=["pdf", "doc", "docx"],
                help="Supported formats: PDF, DOC, DOCX",
                key="cv_upload_existing"
            )

            if cv_file is not None and st.button("Upload CV", key="upload_cv_btn"):
                try:
                    # Process CV file
                    upload_dir = os.path.join(os.getcwd(), "uploads")
                    os.makedirs(upload_dir, exist_ok=True)

                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    safe_filename = "".join(c for c in cv_file.name if c.isalnum() or c in ('-', '_', '.'))
                    unique_filename = f"{timestamp}_{safe_filename}"
                    cv_file_path = os.path.join("uploads", unique_filename)

                    with open(cv_file_path, "wb") as f:
                        f.write(cv_file.getbuffer())

                    # Update database
                    db.execute_update(
                        """
                        UPDATE candidates 
                        SET cv_file_path = %s, cv_file_name = %s 
                        WHERE id = %s
                        """,
                        (cv_file_path, cv_file.name, selected_candidate['id'])
                    )
                    db.commit()

                    st.success(f"✅ CV uploaded successfully for {selected_candidate['name']}!")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error uploading CV: {str(e)}")
        else:
            st.info("All candidates have CVs uploaded")

    # CV Download section
    st.markdown('''
        <div class="stCard">
    ''', unsafe_allow_html=True)

    st.subheader("📄 Download Candidate CV")
    search_name = st.text_input("🔍 Search candidate by name or email", placeholder="Enter name or email...", key="cv_search")

    if search_name:
        try:
            search_results = db.execute('''
                SELECT id, name, email, cv_file_path, cv_file_name 
                FROM candidates 
                WHERE (name ILIKE %s OR email ILIKE %s)
                AND cv_file_path IS NOT NULL
                AND cv_file_name IS NOT NULL
                ORDER BY name
            ''', (f"%{search_name}%", f"%{search_name}%"))

            if search_results:
                st.write("Found matching candidates:")
                for candidate in search_results:
                    try:
                        if candidate['cv_file_path'] and os.path.exists(candidate['cv_file_path']):
                            col1, col2 = st.columns([3, 1])
                            with col1:
                                st.write(f"**{candidate['name']}** ({candidate['email']})")
                            with col2:
                                with open(candidate['cv_file_path'], 'rb') as file:
                                    st.download_button(
                                        label="📄 Download CV",
                                        data=file,
                                        file_name=candidate['cv_file_name'],
                                        mime="application/octet-stream",
                                        key=f"cv_download_{candidate['id']}"
                                    )
                        else:
                            st.warning(f"CV file not found for {candidate['name']}")
                    except Exception as e:
                        st.error(f"Error accessing CV for {candidate['name']}: {str(e)}")
            else:
                st.info("No candidates found with matching name/email or no CVs available")
        except Exception as e:
            st.error(f"Error searching candidates: {str(e)}")

    st.markdown('</div>', unsafe_allow_html=True)

    # Update candidate status section
    with st.expander("📝 Update Candidate Status"):
        st.markdown('''
            <div class="stCard">
        ''', unsafe_allow_html=True)

        try:
            candidates_list = db.execute("SELECT id, name, email FROM candidates ORDER BY name")
            if candidates_list:
                col1, col2 = st.columns(2)
                with col1:
                    selected_candidate = st.selectbox(
                        "Select Candidate",
                        options=candidates_list,
                        format_func=lambda x: f"{x['name']} ({x['email']})"
                    )
                with col2:
                    new_status = st.selectbox(
                        "New Status",
                        st.session_state.dropdown_options['status_options']
                    )

                if st.button("Update Status", use_container_width=True):
                    try:
                        db.execute_update(
                            "UPDATE candidates SET status = %s WHERE id = %s",
                            (new_status, selected_candidate['id'])
                        )
                        db.commit()
                        st.success("✅ Status updated successfully!")
                        st.rerun()
                    except Exception as e:
                        db.rollback()
                        st.error(f"🚫 Error updating status: {str(e)}")
            else:
                st.info("ℹ️ No candidates available")
        except Exception as e:
            st.error(f"🚫 Error loading candidates: {str(e)}")

        st.markdown('</div>', unsafe_allow_html=True)

    # Delete candidate section
    with st.expander("🗑️ Delete Candidate"):
        if 'user' not in st.session_state:
            st.error("Please log in to access this feature")
            return

        auth = Auth()
        if not auth.check_delete_permission(st.session_state.user['id']):
            st.error("🚫 Only administrators can delete candidates")
        else:
            candidates_list = db.execute("SELECT id, name, email FROM candidates")
            if candidates_list:
                selected_candidate = st.selectbox(
                    "Select candidate to delete",
                    options=candidates_list,
                    format_func=lambda x: f"{x['name']} ({x['email']})",
                    key="delete_candidate"
                )

                if st.button("Delete Candidate", type="primary"):
                    try:
                        # Delete associated timesheets first
                        db.execute_update(
                            "DELETE FROM timesheets WHERE candidate_id = %s",
                            (selected_candidate['id'],)
                        )

                        # Then delete the candidate
                        db.execute_update(
                            "DELETE FROM candidates WHERE id = %s",
                            (selected_candidate['id'],)
                        )
                        db.commit()
                        st.success("✅ Candidate deleted successfully!")
                        st.rerun()
                    except Exception as e:
                        db.rollback()
                        st.error(f"🚫 Error deleting candidate: {str(e)}")
            else:
                st.info("No candidates available")