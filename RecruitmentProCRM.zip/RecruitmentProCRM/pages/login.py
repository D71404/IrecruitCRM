import streamlit as st
from models.auth import Auth
import time

def render():
    # Clear session state variables
    st.session_state.authenticated = False
    st.session_state.user = None
    st.session_state.session_id = None

    # Add custom styles
    st.markdown("""
        <style>
        /* Base styles */
        .stApp {
            background-color: #f8f9fa;
        }
        .block-container {
            max-width: 400px !important;
            padding-top: 2rem !important;
            padding-bottom: 1rem !important;
            margin: 0 auto;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 1.5rem;
            width: 100%;
        }
        .logo-container img {
            width: 200px;
            height: auto;
            margin: 0 auto;
            display: block;
        }
        .form-header {
            text-align: center;
            color: #1a1a1a;
            margin-bottom: 1rem;
            font-size: 1.5rem;
            font-weight: 500;
        }
        form {
            background-color: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 360px;
            margin: 0 auto;
            box-sizing: border-box;
        }
        .stTextInput > div {
            margin-bottom: 1rem;
        }
        .stTextInput input {
            width: 100% !important;
            border: 1px solid #e0e0e0;
            padding: 0.75rem !important;
            font-size: 1rem !important;
            border-radius: 6px !important;
            background-color: #f8f9fa !important;
        }
        .stButton > button {
            width: 100% !important;
            background-color: #169e81;
            color: white;
            padding: 0.75rem !important;
            font-size: 1rem !important;
            margin-top: 0.5rem;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .stButton > button:hover {
            background-color: #138a71;
        }

        /* Mobile-specific styles */
        @media screen and (max-width: 480px) {
            .block-container {
                padding: 1rem !important;
            }
            form {
                padding: 1.5rem;
                margin: 0 1rem;
            }
            .logo-container img {
                width: 150px;
            }
            .stTextInput input {
                font-size: 16px !important; /* Prevents zoom on iOS */
            }
            .stButton > button {
                min-height: 44px;
            }
        }
        </style>
    """, unsafe_allow_html=True)

    # Logo section
    st.markdown('<div class="logo-container">', unsafe_allow_html=True)
    try:
        st.image("pixelcut-export.jpeg", width=200)
    except:
        st.title("Recruitment CRM")
    st.markdown('</div>', unsafe_allow_html=True)

    # Login form
    st.markdown('<h2 class="form-header">Login</h2>', unsafe_allow_html=True)

    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")

        if submit:
            if not username or not password:
                st.error("Please enter both username and password")
            else:
                max_retries = 3
                for attempt in range(max_retries):
                    try:
                        auth = Auth()
                        user = auth.authenticate(username, password)
                        if user:
                            # Create session
                            session_id = f"{user['id']}_{int(time.time())}"
                            if auth.create_session(user['id'], session_id):
                                break
                        elif attempt == max_retries - 1:
                            st.error("Invalid username or password")
                            return
                    except Exception as e:
                        if attempt == max_retries - 1:
                            st.error("Login service temporarily unavailable. Please try again.")
                            return
                        time.sleep(1)
                        continue

                if user:
                        st.session_state.authenticated = True
                        st.session_state.user = user
                        st.session_state.session_id = session_id
                        st.success("Login successful!")
                        time.sleep(0.5)
                        st.rerun()
                else:
                    st.error("Invalid username or password")