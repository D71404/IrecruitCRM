import streamlit as st
from models.auth import Auth
from models.database import Database
import pandas as pd
from datetime import datetime, timedelta
from streamlit_calendar import calendar

def render():
    # Add custom CSS for form fields
    st.markdown("""
        <style>
        /* Form input styling */
        .stTextInput input, .stTextArea textarea, .stSelectbox select {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
        }

        /* Form field hover state */
        .stTextInput input:hover, .stTextArea textarea:hover, .stSelectbox select:hover {
            border-color: #888888;
        }

        /* Form field focus state */
        .stTextInput input:focus, .stTextArea textarea:focus, .stSelectbox select:focus {
            border-color: #0078FF;
            box-shadow: 0 0 0 1px #0078FF;
        }

        /* Date input styling */
        .stDateInput input {
            background-color: #ffffff;
            border: 1px solid #cccccc;
            padding: 0.5rem;
            border-radius: 4px;
            color: #000000;
        }
        </style>
    """, unsafe_allow_html=True)

    st.title("Task Management")

    db = Database()

    # Add new task form
    with st.expander("Add New Task"):
        with st.form("new_task"):
            title = st.text_input("Title*")
            description = st.text_area("Description*")
            type = st.selectbox(
                "Type*",
                ["Meeting", "Call", "Email", "Follow-up", "Other"]
            )
            priority = st.selectbox(
                "Priority*",
                ["High", "Medium", "Low"]
            )
            meeting_type = st.selectbox(
                "Meeting Type*",
                ["Interview", "Follow-up", "Assessment", "Onboarding", "Performance Review", "Other"]
            )
            due_date = st.date_input("Due Date*", datetime.now())
            status = st.selectbox(
                "Status*",
                ["New", "In Progress", "Completed", "On Hold"]
            )

            if st.form_submit_button("Add Task"):
                if not all([title, description, meeting_type]):
                    st.error("Title, description, and meeting type are required!")
                else:
                    try:
                        db.execute_update(
                            """
                            INSERT INTO tasks (
                                title, description, type, priority, due_date, status, meeting_type
                            )
                            VALUES (%s, %s, %s, %s, %s, %s, %s)
                            """,
                            (title, description, type, priority, due_date, status, meeting_type)
                        )
                        db.commit()
                        st.success("Task added successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error adding task: {str(e)}")

    # Calendar View
    st.subheader("Task Calendar")
    tasks = db.execute("""
        SELECT id, title, description, due_date, status
        FROM tasks
        WHERE due_date >= CURRENT_DATE - INTERVAL '30 days'
        AND due_date <= CURRENT_DATE + INTERVAL '30 days'
    """)

    if tasks:
        # Convert tasks to calendar events
        calendar_events = []
        for task in tasks:
            color = {
                'New': '#1E90FF',  # Blue
                'In Progress': '#FFD700',  # Gold
                'Completed': '#32CD32',  # Green
                'On Hold': '#FF6347'  # Red
            }.get(task['status'], '#808080')  # Gray as default

            calendar_events.append({
                'title': task['title'],
                'start': task['due_date'].isoformat(),
                'end': task['due_date'].isoformat(),
                'backgroundColor': color,
                'extendedProps': {
                    'description': task['description'],
                    'status': task['status']
                }
            })

        # Calendar options
        calendar_options = {
            "initialView": "dayGridMonth",
            "selectable": True,
            "editable": False,
            "headerToolbar": {
                "left": "prev,next today",
                "center": "title",
                "right": "dayGridMonth,dayGridWeek,dayGridDay"
            }
        }

        # Render calendar
        calendar_data = {
            "events": calendar_events,
            "options": calendar_options
        }
        calendar(calendar_data)

        # Show tasks for selected date
        selected_date = st.date_input("View tasks for date", datetime.now())
        daily_tasks = [t for t in tasks if t['due_date'] == selected_date]

        if daily_tasks:
            st.write(f"Tasks due on {selected_date}:")
            for task in daily_tasks:
                with st.expander(f"{task['title']} ({task['status']})"):
                    st.write(task['description'])
        else:
            st.info(f"No tasks scheduled for {selected_date}")
    else:
        st.info("No tasks found")

    # View tasks (List View)
    st.subheader("Task List")

    # Filter by status
    status_filter = st.multiselect(
        "Filter by Status",
        ["New", "In Progress", "Completed", "On Hold"]
    )

    query = """
        SELECT 
            id,
            title,
            description,
            meeting_type,
            status,
            due_date,
            created_at,
            updated_at
        FROM tasks
        WHERE 1=1
    """
    if status_filter:
        placeholders = ','.join(['%s'] * len(status_filter))
        query += f" AND status IN ({placeholders})"
        tasks = db.execute(query, status_filter)
    else:
        tasks = db.execute(query)

    if tasks:
        df = pd.DataFrame(tasks)
        st.dataframe(
            df,
            column_config={
                "title": st.column_config.TextColumn("Title", width="medium"),
                "description": st.column_config.TextColumn("Description", width="large"),
                "meeting_type": st.column_config.TextColumn("Meeting Type", width="small"),
                "status": st.column_config.TextColumn("Status", width="small"),
                "due_date": st.column_config.DateColumn("Due Date", width="small"),
                "created_at": st.column_config.DatetimeColumn("Created", width="small"),
                "updated_at": st.column_config.DatetimeColumn("Updated", width="small")
            },
            hide_index=True,
            use_container_width=True
        )
    else:
        st.info("No tasks found")

    # Update task status
    with st.expander("Update Task"):
        all_tasks = db.execute("SELECT id, title FROM tasks")
        if all_tasks:
            selected_task = st.selectbox(
                "Select Task",
                options=all_tasks,
                format_func=lambda x: x['title']
            )

            new_status = st.selectbox(
                "New Status",
                ["New", "In Progress", "Completed", "On Hold"]
            )

            if st.button("Update Status"):
                db.execute_update(
                    "UPDATE tasks SET status = %s WHERE id = %s",
                    (new_status, selected_task['id'])
                )
                db.commit()
                st.success("Task updated successfully!")
                st.rerun()

    # Delete task section
    with st.expander("🗑️ Delete Task"):
        auth = Auth()
        if not auth.check_delete_permission(st.session_state.user['id']):
            st.error("🚫 Only administrators can delete tasks")
        else:
            tasks_list = db.execute("SELECT id, title FROM tasks")
            if tasks_list:
                selected_task = st.selectbox(
                    "Select task to delete",
                    options=tasks_list,
                    format_func=lambda x: x['title'],
                    key="delete_task"
                )

                if st.button("Delete Task", type="primary"):
                    try:
                        db.execute_update(
                            "DELETE FROM tasks WHERE id = %s",
                            (selected_task['id'],)
                        )
                        db.commit()
                        st.success("✅ Task deleted successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"🚫 Error deleting task: {str(e)}")
            else:
                st.info("No tasks available")