"""Constants used throughout the application"""

# Industry options available across the application
VALID_INDUSTRIES = [
    "Technology",
    "Healthcare",
    "Finance",
    "Manufacturing",
    "Retail",
    "Construction",
    "Education",
    "Hospitality",
    "Housekeeping",
    "Security",
    "Administration",
    "Customer Service",
    "Sales",
    "Marketing",
    "Social Worker",
    "Legal",
    "Business",
    "Other"
]
