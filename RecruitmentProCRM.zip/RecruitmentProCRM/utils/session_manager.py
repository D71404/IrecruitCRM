from models.database import Database
from datetime import datetime, timedelta
import time
import logging

class SessionManager:
    def __init__(self):
        self.db = Database()
        self.setup_logging()
    
    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('SessionManager')
    
    def cleanup_expired_sessions(self):
        """Remove expired sessions from the database"""
        try:
            result = self.db.execute_update("""
                DELETE FROM sessions 
                WHERE expires_at < CURRENT_TIMESTAMP
                RETURNING id
            """)
            if result:
                self.logger.info(f"Cleaned up {len(result)} expired sessions")
            self.db.commit()
        except Exception as e:
            self.logger.error(f"Error cleaning up sessions: {str(e)}")
    
    def extend_active_sessions(self):
        """Extend sessions that are still active but close to expiration"""
        try:
            result = self.db.execute_update("""
                UPDATE sessions 
                SET expires_at = CURRENT_TIMESTAMP + INTERVAL '7 days',
                    updated_at = CURRENT_TIMESTAMP
                WHERE expires_at < CURRENT_TIMESTAMP + INTERVAL '1 day'
                AND expires_at > CURRENT_TIMESTAMP
                RETURNING id
            """)
            if result:
                self.logger.info(f"Extended {len(result)} active sessions")
            self.db.commit()
        except Exception as e:
            self.logger.error(f"Error extending sessions: {str(e)}")
    
    def run_maintenance(self):
        """Run all session maintenance tasks"""
        self.logger.info("Starting session maintenance")
        self.cleanup_expired_sessions()
        self.extend_active_sessions()
        self.logger.info("Session maintenance completed")

def maintain_sessions():
    """Function to be called periodically for session maintenance"""
    manager = SessionManager()
    while True:
        try:
            manager.run_maintenance()
            time.sleep(1800)  # Run maintenance every 30 minutes
        except Exception as e:
            logging.error(f"Session maintenance error: {str(e)}")
            try:
                manager.db = Database()  # Reconnect database
            except Exception as db_error:
                logging.error(f"Database reconnection error: {str(db_error)}")
            time.sleep(300)  # Wait 5 minutes on error before retrying
