from .database import Database
from .auth import Auth
import json
from datetime import datetime
from typing import Optional, List, Union

class Candidate:
    def __init__(self):
        self.db = Database()

    def validate_salary(self, salary: Optional[float]) -> Optional[float]:
        """Validate salary input"""
        if salary is not None:
            if not isinstance(salary, (int, float)) or salary < 0:
                raise ValueError("Salary must be a positive number")
            return float(salary)
        return None

    def validate_experience_years(self, years: Optional[int]) -> Optional[int]:
        """Validate experience years"""
        if years is not None:
            if not isinstance(years, int) or years < 0:
                raise ValueError("Experience years must be a positive integer")
            return years
        return None

    def check_duplicate(self, name: str, email: str, phone: Optional[str] = None) -> List[dict]:
        """Check if a candidate with similar details already exists"""
        try:
            query = """
                SELECT id, name, email, phone 
                FROM candidates 
                WHERE LOWER(name) = LOWER(%s) 
                OR LOWER(email) = LOWER(%s)
                OR (phone IS NOT NULL AND phone = %s)
            """
            result = self.db.execute(query, (name, email, phone))
            return result
        except Exception as e:
            print(f"Error checking duplicate: {str(e)}")
            return None

    def create(self, 
               name: str, 
               email: str, 
               phone: Optional[str] = None,
               industry: Optional[List[str]] = None,
               profile_type: str = 'Temp',
               status: str = 'Active',
               source_type: Optional[str] = None,
               source_details: Optional[str] = None,
               cv_file: Optional[str] = None,
               cv_file_name: Optional[str] = None,
               skills: Optional[List[str]] = None,
               experience_years: Optional[int] = None,
               current_salary: Optional[float] = None,
               expected_salary: Optional[float] = None,
               notice_period: Optional[str] = None,
               availability_date: Optional[str] = None,
               preferred_location: Optional[List[str]] = None,
               education_level: Optional[str] = None,
               certifications: Optional[List[str]] = None,
               languages: Optional[List[str]] = None) -> dict:
        """Create a new candidate with comprehensive validation"""
        try:
            # Basic validation
            if not name or not email:
                raise ValueError("Name and email are required")
            if not profile_type:
                raise ValueError("Profile type is required")

            # Validate experience and salaries
            experience_years = self.validate_experience_years(experience_years)
            current_salary = self.validate_salary(current_salary)
            expected_salary = self.validate_salary(expected_salary)

            # Check for duplicates
            duplicates = self.check_duplicate(name, email, phone)
            if duplicates:
                duplicate_details = []
                for dup in duplicates:
                    match_type = []
                    if dup['name'].lower() == name.lower():
                        match_type.append("name")
                    if dup['email'].lower() == email.lower():
                        match_type.append("email")
                    if phone and dup['phone'] and dup['phone'] == phone:
                        match_type.append("phone")
                    duplicate_details.append(f"Candidate with matching {' and '.join(match_type)}: {dup['name']} ({dup['email']})")
                raise ValueError(f"Similar candidate(s) already exist:\n" + "\n".join(duplicate_details))

            # Prepare arrays for PostgreSQL array type
            industry_array = industry if industry else []
            skills_array = skills if skills else []
            preferred_location_array = preferred_location if preferred_location else []
            certifications_array = certifications if certifications else []
            languages_array = languages if languages else []

            query = '''
                INSERT INTO candidates (
                    name, email, phone, industry, profile_type, status,
                    cv_file_path, cv_file_name, cv_upload_date,
                    source_type, source_details, skills,
                    experience_years, current_salary, expected_salary,
                    notice_period, availability_date, preferred_location,
                    education_level, certifications, languages,
                    created_at, updated_at
                )
                VALUES (
                    %s, %s, %s, %s, %s, %s,
                    %s, %s, CASE WHEN %s IS NOT NULL THEN CURRENT_TIMESTAMP ELSE NULL END,
                    %s, %s, %s,
                    %s, %s, %s,
                    %s, %s::date, %s,
                    %s, %s, %s,
                    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
                RETURNING id, name, email, phone, industry, profile_type, status, created_at
            '''

            result = self.db.execute_update(
                query, 
                (name, email, phone, 
                 industry_array, profile_type, status,
                 cv_file, cv_file_name, cv_file,
                 source_type, source_details, skills_array,
                 experience_years, current_salary, expected_salary,
                 notice_period, availability_date, preferred_location_array,
                 education_level, certifications_array, languages_array)
            )

            if not result:
                raise Exception("Failed to create candidate - no result returned")

            return result

        except ValueError as e:
            raise ValueError(str(e))
        except Exception as e:
            print(f"Unexpected error: {str(e)}")
            raise Exception(f"Failed to create candidate: {str(e)}")

    def get_all(self):
        """Get all candidates with enhanced field support"""
        try:
            query = '''
                SELECT 
                    id, name, email, phone, industry, profile_type, status,
                    created_at, cv_file_path, cv_file_name,
                    source_type, source_details, skills,
                    experience_years, current_salary, expected_salary,
                    notice_period, availability_date, preferred_location,
                    education_level, certifications, languages
                FROM candidates 
                ORDER BY created_at DESC
            '''
            results = self.db.execute(query)

            if not results:
                return []

            # Format results for display
            formatted_results = []
            for row in results:
                formatted_row = dict(row)
                # Parse JSON fields
                json_fields = ['industry', 'skills', 'preferred_location', 'certifications', 'languages']
                for field in json_fields:
                    if field in formatted_row and formatted_row[field]:
                        if isinstance(formatted_row[field], str):
                            try:
                                formatted_row[field] = json.loads(formatted_row[field])
                            except json.JSONDecodeError:
                                formatted_row[field] = [formatted_row[field]]
                        elif not isinstance(formatted_row[field], list):
                            formatted_row[field] = [str(formatted_row[field])]
                formatted_results.append(formatted_row)

            return formatted_results

        except Exception as e:
            print(f"Error in get_all: {str(e)}")
            raise Exception(f"Failed to retrieve candidates: {str(e)}")

    def get_by_id(self, id: int) -> dict:
        """Get a candidate by ID with all fields"""
        try:
            query = """
                SELECT *
                FROM candidates 
                WHERE id = %s
            """
            result = self.db.execute_one(query, (id,))
            if not result:
                raise Exception("Candidate not found")

            # Parse JSON fields
            json_fields = ['industry', 'skills', 'preferred_location', 'certifications', 'languages']
            for field in json_fields:
                if field in result and result[field]:
                    if isinstance(result[field], str):
                        try:
                            result[field] = json.loads(result[field])
                        except json.JSONDecodeError:
                            result[field] = [result[field]]
                    elif not isinstance(result[field], list):
                        result[field] = [str(result[field])]

            return result
        except Exception as e:
            raise Exception(f"Failed to retrieve candidate: {str(e)}")

    def update_status(self, id: int, status: str) -> dict:
        """Update candidate status with validation"""
        try:
            valid_statuses = ["Active", "Inactive", "Placed", "Interviewing"]
            if status not in valid_statuses:
                raise ValueError(f"Invalid status. Must be one of: {', '.join(valid_statuses)}")

            query = """
                UPDATE candidates 
                SET status = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
                RETURNING id, name, email, status
            """
            result = self.db.execute_one(query, (status, id))
            if not result:
                raise Exception("Candidate not found")
            return result
        except ValueError as e:
            raise ValueError(str(e))
        except Exception as e:
            raise Exception(f"Failed to update candidate status: {str(e)}")

    def search(self, term: Optional[str] = None) -> List[dict]:
        """Enhanced search with support for all fields"""
        try:
            if not term:
                return self.get_all()

            # Check if the term is a numeric ID
            if term.isdigit():
                return self.search_by_id(int(term))

            query = '''
                SELECT *
                FROM candidates 
                WHERE 
                    name ILIKE %s 
                    OR email ILIKE %s
                    OR phone ILIKE %s
                    OR profile_type ILIKE %s
                    OR status ILIKE %s
                    OR EXISTS (
                        SELECT 1 
                        FROM unnest(industry) AS ind 
                        WHERE ind ILIKE %s
                    )
                    OR EXISTS (
                        SELECT 1 
                        FROM unnest(skills) AS skill 
                        WHERE skill ILIKE %s
                    )
                    OR education_level ILIKE %s
                ORDER BY created_at DESC
            '''
            search_term = f"%{term}%"
            results = self.db.execute(query, (search_term,) * 8)

            if not results:
                return []

            # Format results
            formatted_results = []
            for row in results:
                formatted_row = dict(row)
                json_fields = ['industry', 'skills', 'preferred_location', 'certifications', 'languages']
                for field in json_fields:
                    if field in formatted_row and formatted_row[field]:
                        if isinstance(formatted_row[field], str):
                            try:
                                formatted_row[field] = json.loads(formatted_row[field])
                            except json.JSONDecodeError:
                                formatted_row[field] = [formatted_row[field]]
                        elif not isinstance(formatted_row[field], list):
                            formatted_row[field] = [str(formatted_row[field])]
                formatted_results.append(formatted_row)

            return formatted_results
        except Exception as e:
            print(f"Search error: {str(e)}")
            raise Exception(f"Failed to search candidates: {str(e)}")

    def delete(self, id: int, user_id: int) -> bool:
        """Delete a candidate with proper cleanup"""
        try:
            auth = Auth()
            if not auth.check_delete_permission(user_id):
                raise Exception("Only administrators can delete candidates")

            try:
                # First delete associated timesheets
                delete_timesheets_query = '''
                    DELETE FROM timesheets 
                    WHERE candidate_id = %s
                '''
                self.db.execute_update(delete_timesheets_query, (id,))

                # Delete job assignments
                delete_assignments_query = '''
                    DELETE FROM job_assignments 
                    WHERE candidate_id = %s
                '''
                self.db.execute_update(delete_assignments_query, (id,))

                # Then delete the candidate
                delete_query = '''
                    DELETE FROM candidates 
                    WHERE id = %s
                    RETURNING id
                '''
                result = self.db.execute_one(delete_query, (id,))
                if not result:
                    raise Exception("Candidate not found")

                return True
            except Exception as e:
                raise e
        except Exception as e:
            raise Exception(f"Failed to delete candidate: {str(e)}")

    def search_by_id(self, candidate_id):
        """Search candidate by ID"""
        try:
            query = '''
                SELECT *
                FROM candidates 
                WHERE id = %s
                ORDER BY created_at DESC
            '''
            return self.db.execute(query, (candidate_id,))
        except Exception as e:
            print(f"Search by ID error: {str(e)}")
            raise Exception(f"Failed to search candidate by ID: {str(e)}")