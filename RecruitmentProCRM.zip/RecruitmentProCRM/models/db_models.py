from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask import Flask
import os
import bcrypt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    role = db.Column(db.String(20), nullable=False, default='user')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

    def set_password(self, password):
        password_bytes = password.encode('utf-8')
        salt = bcrypt.gensalt()
        self.password_hash = bcrypt.hashpw(password_bytes, salt).decode('utf-8')

    def check_password(self, password):
        password_bytes = password.encode('utf-8')
        stored_hash_bytes = self.password_hash.encode('utf-8')
        return bcrypt.checkpw(password_bytes, stored_hash_bytes)

class Session(db.Model):
    __tablename__ = 'sessions'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    session_id = db.Column(db.String(255), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

class Candidate(db.Model):
    __tablename__ = 'candidates'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    industry = db.Column(db.ARRAY(db.String))
    profile_type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(50), nullable=False)
    cv_file_path = db.Column(db.Text)
    cv_file_name = db.Column(db.Text)
    cv_upload_date = db.Column(db.DateTime)
    source_type = db.Column(db.String(50))
    source_details = db.Column(db.Text)
    skills = db.Column(db.ARRAY(db.String))
    experience_years = db.Column(db.Integer)
    current_salary = db.Column(db.Numeric(10, 2))
    expected_salary = db.Column(db.Numeric(10, 2))
    notice_period = db.Column(db.String(50))
    availability_date = db.Column(db.Date)
    preferred_location = db.Column(db.ARRAY(db.String))
    education_level = db.Column(db.String(100))
    certifications = db.Column(db.ARRAY(db.String))
    languages = db.Column(db.ARRAY(db.String))
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

class Client(db.Model):
    __tablename__ = 'clients'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    company = db.Column(db.String(100), nullable=False)
    value = db.Column(db.Numeric(10, 2), nullable=False, server_default='0')
    industry = db.Column(db.ARRAY(db.String))
    email = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    country = db.Column(db.String(100))
    postal_code = db.Column(db.String(20))
    website = db.Column(db.String(200))
    primary_contact_name = db.Column(db.String(100))
    primary_contact_position = db.Column(db.String(100))
    billing_email = db.Column(db.String(100))
    payment_terms = db.Column(db.String(50))
    notes = db.Column(db.Text)
    status = db.Column(db.String(50), nullable=False, server_default='Active')
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

class Job(db.Model):
    __tablename__ = 'jobs'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'))
    description = db.Column(db.Text, nullable=False)
    industry = db.Column(db.ARRAY(db.String), nullable=False)
    required_skills = db.Column(db.ARRAY(db.String))
    preferred_skills = db.Column(db.ARRAY(db.String))
    min_experience_years = db.Column(db.Integer)
    max_experience_years = db.Column(db.Integer)
    salary_min = db.Column(db.Numeric(10, 2))
    salary_max = db.Column(db.Numeric(10, 2))
    salary_type = db.Column(db.String(50))
    location = db.Column(db.String(100))
    work_type = db.Column(db.String(50))
    employment_type = db.Column(db.String(50))
    duration_months = db.Column(db.Integer)
    urgency_level = db.Column(db.String(50))
    status = db.Column(db.String(50), nullable=False)
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

class JobAssignment(db.Model):
    __tablename__ = 'job_assignments'

    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'))
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidates.id'))
    status = db.Column(db.String(50), nullable=False)
    notes = db.Column(db.Text)
    assigned_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())
    __table_args__ = (db.UniqueConstraint('job_id', 'candidate_id'),)

class Timesheet(db.Model):
    __tablename__ = 'timesheets'

    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidates.id'))
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'))
    date = db.Column(db.Date, nullable=False)
    week_number = db.Column(db.Integer)
    month = db.Column(db.Integer)
    year = db.Column(db.Integer)
    hours_worked = db.Column(db.Numeric(5, 2))
    overtime_hours = db.Column(db.Numeric(5, 2))
    rate_per_hour = db.Column(db.Numeric(10, 2))
    overtime_rate = db.Column(db.Numeric(10, 2))
    status = db.Column(db.String(50), nullable=False)
    approved_by = db.Column(db.Integer)
    approved_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    original_file = db.Column(db.LargeBinary)
    original_filename = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())

class Task(db.Model):
    __tablename__ = 'tasks'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    type = db.Column(db.String(50), nullable=False)
    priority = db.Column(db.String(50), nullable=False)
    meeting_type = db.Column(db.String(50))  
    assigned_to = db.Column(db.Integer)
    related_to_type = db.Column(db.String(50))
    related_to_id = db.Column(db.Integer)
    due_date = db.Column(db.Date)
    reminder_date = db.Column(db.Date)
    completion_date = db.Column(db.DateTime)
    status = db.Column(db.String(50), nullable=False)
    notes = db.Column(db.Text)
    created_by = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, server_default=db.func.now(), onupdate=db.func.now())