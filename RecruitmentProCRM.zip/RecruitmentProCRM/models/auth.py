import bcrypt
from models.database import Database
from typing import Optional, Dict, Any
import time
from datetime import datetime, timedelta

class Auth:
    def __init__(self):
        self.db = Database()
        self._ensure_session_cleanup()

    def hash_password(self, password: str) -> str:
        """Hash a password using bcrypt"""
        try:
            salt = bcrypt.gensalt()
            hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
            return hashed.decode('utf-8')
        except Exception as e:
            print(f"Password hashing error: {str(e)}")
            raise Exception("Failed to hash password")

    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify a password against a hash"""
        try:
            if not password or not hashed:
                return False

            if not isinstance(hashed, str):
                hashed = hashed.decode('utf-8')

            if not hashed.startswith('$2'):  # Ensure it's a valid bcrypt hash
                return False

            result = bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
            return result
        except Exception as e:
            print(f"Password verification error: {str(e)}")
            return False

    def authenticate(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        """Authenticate a user with username and password"""
        try:
            user = self.db.execute_one(
                "SELECT * FROM users WHERE username = %s",
                (username,)
            )
            print(f"Found user: {user is not None}")

            if not user:
                print("User not found")
                return None

            is_valid = self.verify_password(password, user['password_hash'])
            print(f"Password verification result: {is_valid}")

            if is_valid:
                return user
            return None
        except Exception as e:
            print(f"Authentication error: {str(e)}")
            return None

    def register_user(self, username: str, email: str, password: str, role: str = 'user') -> bool:
        """Register a new user"""
        try:
            # Check if username already exists
            existing_user = self.db.execute_one(
                "SELECT id FROM users WHERE username = %s",
                (username,)
            )
            if existing_user:
                raise Exception("Username already exists")

            # Hash the password and store as string
            hashed_password = self.hash_password(password)
            print(f"Generated password hash for new user: {hashed_password[:10]}...")

            # Insert the new user
            user = self.db.execute_update("""
                INSERT INTO users (username, email, password_hash, role)
                VALUES (%s, %s, %s, %s)
                RETURNING id, username, email, role
            """, (username, email, hashed_password, role))

            if not user:
                raise Exception("Failed to create user")

            # Store the actual password in stored_passwords table
            try:
                self.db.execute_update("""
                    INSERT INTO stored_passwords (user_id, password)
                    VALUES (%s, %s)
                    ON CONFLICT (user_id) 
                    DO UPDATE SET password = EXCLUDED.password
                """, (user[0]['id'], password))

                print(f"Stored password for user {user[0]['id']}")
                self.db.commit()
            except Exception as e:
                print(f"Error storing password: {str(e)}")
                self.db.rollback()

            print(f"User registered successfully: {username}")
            return True
        except Exception as e:
            print(f"User registration error: {str(e)}")
            self.db.rollback()
            raise Exception(f"Failed to register user: {str(e)}")

    def get_user_role(self, user_id: int) -> Optional[str]:
        """Get user's role"""
        try:
            user = self.db.execute_one(
                "SELECT role FROM users WHERE id = %s",
                (user_id,)
            )
            return user['role'] if user else None
        except Exception as e:
            print(f"Error getting user role: {str(e)}")
            return None

    def check_permission(self, user_id: int, required_role: str) -> bool:
        """Check if user has required role"""
        try:
            role = self.get_user_role(user_id)
            if not role:
                return False

            # Admin has access to everything
            if role == 'admin':
                return True

            # For regular users, only allow if they match the required role
            return role == required_role
        except Exception:
            return False

    def check_delete_permission(self, user_id: int) -> bool:
        """Check if user has delete permission (admin only)"""
        return self.check_permission(user_id, 'admin')

    def can_delete_records(self, user_id: int) -> bool:
        """Check if user can delete records (admin only)"""
        return self.check_permission(user_id, 'admin')

    def can_assign_candidates(self, user_id: int) -> bool:
        """Check if user can assign candidates"""
        try:
            role = self.get_user_role(user_id)
            return role in ['admin', 'user']  # Both admin and regular users can assign
        except Exception:
            return False

    def can_modify_records(self, user_id: int) -> bool:
        """Check if user can modify records"""
        try:
            role = self.get_user_role(user_id)
            return role in ['admin', 'user']  # Both admin and regular users can modify
        except Exception:
            return False

    def can_view_client_value(self, user_id: int) -> bool:
        """Check if user can view client value (admin only)"""
        return self.check_permission(user_id, 'admin')

    def can_delete_timesheets(self, user_id: int) -> bool:
        """Check if user can delete timesheets (admin only)"""
        return self.check_permission(user_id, 'admin')

    def get_all_users(self) -> list:
        """Get all users without sensitive information"""
        try:
            return self.db.execute("SELECT id, username, email, role, created_at FROM users")
        except Exception as e:
            print(f"Error getting users: {str(e)}")
            return []

    def get_all_users_with_passwords(self) -> list:
        """Get all users including actual passwords (admin only)"""
        try:
            # Ensure stored_passwords table exists and create it if it doesn't
            self.db.execute("""
                CREATE TABLE IF NOT EXISTS stored_passwords (
                    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                    password TEXT NOT NULL
                )
            """)

            # Get all users with their stored passwords
            users = self.db.execute("""
                SELECT 
                    u.id,
                    u.username,
                    u.email,
                    u.role,
                    u.created_at,
                    sp.password as stored_password
                FROM users u
                LEFT JOIN stored_passwords sp ON u.id = sp.user_id
                ORDER BY u.id ASC
            """)

            # For any user without a stored password, store their hashed password
            for user in users:
                if not user.get('stored_password'):
                    # Get the original password from the registration process if available
                    original_password = self.db.execute_one("""
                        SELECT password_hash FROM users WHERE id = %s
                    """, (user['id'],))

                    if original_password:
                        # Store the password in stored_passwords table
                        self.db.execute_update("""
                            INSERT INTO stored_passwords (user_id, password)
                            VALUES (%s, %s)
                            ON CONFLICT (user_id) DO UPDATE SET password = EXCLUDED.password
                        """, (user['id'], '••••••••'))
                        user['stored_password'] = '••••••••'

            # Print debug information
            print(f"Retrieved {len(users)} users with stored passwords")
            return users
        except Exception as e:
            print(f"Error getting users with passwords: {str(e)}")
            return []

    def store_password(self, user_id: int, password: str) -> bool:
        """Store the actual password for admin view"""
        try:
            self.db.execute_update("""
                INSERT INTO stored_passwords (user_id, password)
                VALUES (%s, %s)
                ON CONFLICT (user_id) 
                DO UPDATE SET password = EXCLUDED.password
            """, (user_id, password))
            self.db.commit()
            return True
        except Exception as e:
            print(f"Error storing password: {str(e)}")
            return False

    def update_role(self, user_id: int, new_role: str) -> bool:
        """Update user's role"""
        try:
            if new_role == 'user':
                # Check if this would remove the last admin
                current_user = self.db.execute_one(
                    "SELECT role FROM users WHERE id = %s",
                    (user_id,)
                )

                if current_user and current_user['role'] == 'admin':
                    admin_count = self.db.execute_one(
                        "SELECT COUNT(*) as count FROM users WHERE role = 'admin'"
                    )
                    if admin_count['count'] <= 1:
                        raise Exception("Cannot remove the last admin user")

            # Update the role and commit the transaction
            self.db.execute_update(
                "UPDATE users SET role = %s WHERE id = %s",
                (new_role, user_id)
            )
            self.db.commit()
            print(f"Successfully updated role for user {user_id} to {new_role}")
            return True
        except Exception as e:
            print(f"Error updating role: {str(e)}")
            raise Exception(f"Failed to update user role: {str(e)}")

    def _ensure_session_cleanup(self):
        """Ensure expired sessions are cleaned up"""
        try:
            self.db.execute_update("""
                DELETE FROM sessions 
                WHERE expires_at < CURRENT_TIMESTAMP
            """)
            self.db.commit()
        except Exception as e:
            print(f"Session cleanup error: {str(e)}")

    def validate_session(self, user_id: int, session_id: str) -> bool:
        """Validate if a session is still valid and extend it if needed"""
        try:
            # Get session details including expiration
            session = self.db.execute_one("""
                SELECT 
                    session_id,
                    expires_at,
                    CURRENT_TIMESTAMP > expires_at as is_expired,
                    CURRENT_TIMESTAMP - created_at as session_age
                FROM sessions 
                WHERE user_id = %s 
                AND session_id = %s
            """, (user_id, session_id))

            if not session:
                print("No session found")
                return False

            if session['is_expired']:
                print("Session expired")
                self.clear_session(user_id)
                return False

            # Extend session if it's valid and was last updated more than 1 hour ago
            self.db.execute_update("""
                UPDATE sessions 
                SET expires_at = CURRENT_TIMESTAMP + INTERVAL '7 days',
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = %s 
                AND session_id = %s 
                AND (updated_at IS NULL OR updated_at < CURRENT_TIMESTAMP - INTERVAL '1 hour')
            """, (user_id, session_id))
            self.db.commit()

            return True
        except Exception as e:
            print(f"Session validation error: {str(e)}")
            return False

    def create_session(self, user_id: int, session_id: str) -> bool:
        """Create a new session for a user"""
        try:
            # Ensure sessions table exists with updated schema
            self.db.execute_update("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id SERIAL PRIMARY KEY,
                    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                    session_id TEXT NOT NULL,
                    expires_at TIMESTAMP NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, session_id)
                )
            """)

            # Delete any existing sessions for this user
            self.db.execute_update("""
                DELETE FROM sessions WHERE user_id = %s
            """, (user_id,))

            # Create new session (valid for 7 days initially)
            self.db.execute_update("""
                INSERT INTO sessions (user_id, session_id, expires_at)
                VALUES (%s, %s, CURRENT_TIMESTAMP + INTERVAL '7 days')
            """, (user_id, session_id))

            self.db.commit()
            return True
        except Exception as e:
            print(f"Session creation error: {str(e)}")
            return False

    def clear_session(self, user_id: int) -> bool:
        """Clear all sessions for a user"""
        try:
            self.db.execute_update("""
                DELETE FROM sessions WHERE user_id = %s
            """, (user_id,))
            self.db.commit()
            return True
        except Exception as e:
            print(f"Session clearing error: {str(e)}")
            return False

    def get_active_session_count(self) -> int:
        """Get count of active sessions"""
        try:
            result = self.db.execute_one("""
                SELECT COUNT(*) as count 
                FROM sessions 
                WHERE expires_at > CURRENT_TIMESTAMP
            """)
            return result['count'] if result else 0
        except Exception as e:
            print(f"Error getting active session count: {str(e)}")
            return 0

    def change_password(self, user_id: int, current_password: str, new_password: str) -> bool:
        """Change a user's password"""
        try:
            # First verify the current password
            user = self.db.execute_one(
                "SELECT password_hash FROM users WHERE id = %s",
                (user_id,)
            )

            if not user or not self.verify_password(current_password, user['password_hash']):
                raise Exception("Current password is incorrect")

            # Hash the new password
            new_password_hash = self.hash_password(new_password)

            # Update the password
            self.db.execute_update(
                "UPDATE users SET password_hash = %s WHERE id = %s",
                (new_password_hash, user_id)
            )
            self.db.commit()
            return True
        except Exception as e:
            print(f"Password change error: {str(e)}")
            raise Exception(f"Failed to change password: {str(e)}")

    def delete_user(self, user_id: int) -> bool:
        """Delete a user and their associated sessions"""
        try:
            # First clear any active sessions
            self.clear_session(user_id)

            # Then delete the user
            self.db.execute_update("""
                DELETE FROM users WHERE id = %s
            """, (user_id,))
            self.db.commit()
            return True
        except Exception as e:
            print(f"User deletion error: {str(e)}")
            return False