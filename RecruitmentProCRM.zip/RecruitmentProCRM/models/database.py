import os
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import pool
import time
import logging

class Database:
    _instance = None
    _pool = None
    MAX_RETRIES = 3
    RETRY_DELAY = 1  # seconds

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Database, cls).__new__(cls)
            cls._instance._initialize_pool()
        return cls._instance

    def _initialize_pool(self):
        """Initialize the connection pool with retry mechanism and optimized settings"""
        retry_count = 0
        while retry_count < self.MAX_RETRIES:
            try:
                if self._pool is None or self._pool.closed:
                    self._pool = psycopg2.pool.SimpleConnectionPool(
                        minconn=5,
                        maxconn=20,
                        host=os.getenv('PGHOST'),
                        database=os.getenv('PGDATABASE'),
                        user=os.getenv('PGUSER'),
                        password=os.getenv('PGPASSWORD'),
                        port=os.getenv('PGPORT')
                    )
                break
            except psycopg2.Error as e:
                retry_count += 1
                if retry_count == self.MAX_RETRIES:
                    logging.error(f"Failed to initialize database pool after {self.MAX_RETRIES} attempts: {str(e)}")
                    raise
                time.sleep(self.RETRY_DELAY)

        # Create tables when pool is initialized
        self.create_tables()

    def get_connection(self):
        """Get a connection from the pool with retry mechanism"""
        retry_count = 0
        while retry_count < self.MAX_RETRIES:
            try:
                conn = self._pool.getconn()
                if conn.closed:
                    self._pool.putconn(conn)
                    self._initialize_pool()
                    conn = self._pool.getconn()
                return conn
            except (psycopg2.Error, AttributeError) as e:
                retry_count += 1
                if retry_count == self.MAX_RETRIES:
                    logging.error(f"Failed to get database connection after {self.MAX_RETRIES} attempts: {str(e)}")
                    raise
                time.sleep(self.RETRY_DELAY)
                self._initialize_pool()

    def return_connection(self, conn):
        """Return a connection to the pool"""
        if conn and not conn.closed:
            self._pool.putconn(conn)

    def create_tables(self):
        """Create database tables with enhanced fields"""
        conn = None
        try:
            conn = self.get_connection()
            with conn.cursor() as cur:
                # Candidates table with enhanced fields
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS candidates (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        email VARCHAR(100) UNIQUE NOT NULL,
                        phone VARCHAR(20),
                        industry TEXT[],
                        profile_type VARCHAR(50) NOT NULL,
                        status VARCHAR(50) NOT NULL,
                        cv_file_path TEXT,
                        cv_file_name TEXT,
                        cv_upload_date TIMESTAMP,
                        source_type VARCHAR(50),
                        source_details TEXT,
                        skills TEXT[],
                        experience_years INTEGER,
                        current_salary DECIMAL(10,2),
                        expected_salary DECIMAL(10,2),
                        notice_period VARCHAR(50),
                        availability_date DATE,
                        preferred_location TEXT[],
                        education_level VARCHAR(100),
                        certifications TEXT[],
                        languages TEXT[],
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Clients table with enhanced fields
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS clients (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        company VARCHAR(100) NOT NULL,
                        industry TEXT[],
                        email VARCHAR(100),
                        phone VARCHAR(20),
                        address TEXT,
                        city VARCHAR(100),
                        country VARCHAR(100),
                        postal_code VARCHAR(20),
                        website VARCHAR(200),
                        primary_contact_name VARCHAR(100),
                        primary_contact_position VARCHAR(100),
                        billing_email VARCHAR(100),
                        payment_terms VARCHAR(50),
                        notes TEXT,
                        status VARCHAR(50) NOT NULL DEFAULT 'Active',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Jobs table with enhanced fields
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS jobs (
                        id SERIAL PRIMARY KEY,
                        title VARCHAR(100) NOT NULL,
                        client_id INTEGER REFERENCES clients(id),
                        description TEXT NOT NULL,
                        industry TEXT[] NOT NULL,
                        required_skills TEXT[],
                        preferred_skills TEXT[],
                        min_experience_years INTEGER,
                        max_experience_years INTEGER,
                        salary_min DECIMAL(10,2),
                        salary_max DECIMAL(10,2),
                        salary_type VARCHAR(50),
                        location VARCHAR(100),
                        work_type VARCHAR(50),
                        employment_type VARCHAR(50),
                        duration_months INTEGER,
                        urgency_level VARCHAR(50),
                        status VARCHAR(50) NOT NULL,
                        start_date DATE,
                        end_date DATE,
                        initial_candidates INTEGER[],
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Timesheets table with enhanced fields
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS timesheets (
                        id SERIAL PRIMARY KEY,
                        candidate_id INTEGER REFERENCES candidates(id),
                        job_id INTEGER REFERENCES jobs(id),
                        date DATE NOT NULL,
                        week_number INTEGER,
                        month INTEGER,
                        year INTEGER,
                        hours_worked DECIMAL(5,2),
                        overtime_hours DECIMAL(5,2),
                        rate_per_hour DECIMAL(10,2),
                        overtime_rate DECIMAL(10,2),
                        status VARCHAR(50) NOT NULL,
                        approved_by INTEGER,
                        approved_at TIMESTAMP,
                        notes TEXT,
                        original_file BYTEA,
                        original_filename VARCHAR(255),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Tasks table with enhanced fields
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS tasks (
                        id SERIAL PRIMARY KEY,
                        title VARCHAR(100) NOT NULL,
                        description TEXT,
                        type VARCHAR(50) NOT NULL,
                        priority VARCHAR(50) NOT NULL,
                        assigned_to INTEGER,
                        related_to_type VARCHAR(50),
                        related_to_id INTEGER,
                        due_date DATE,
                        reminder_date DATE,
                        completion_date TIMESTAMP,
                        status VARCHAR(50) NOT NULL,
                        notes TEXT,
                        created_by INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Job Assignments table for tracking candidate assignments
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS job_assignments (
                        id SERIAL PRIMARY KEY,
                        job_id INTEGER REFERENCES jobs(id),
                        candidate_id INTEGER REFERENCES candidates(id),
                        status VARCHAR(50) NOT NULL,
                        assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        notes TEXT,
                        UNIQUE(job_id, candidate_id)
                    )
                """)

            conn.commit()
        except psycopg2.Error as e:
            if conn:
                conn.rollback()
            logging.error(f"Error creating tables: {str(e)}")
            raise
        finally:
            if conn:
                self.return_connection(conn)

    def execute(self, query, params=None):
        """Execute a query and return all results"""
        conn = None
        try:
            conn = self.get_connection()
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query, params)
                return cur.fetchall()
        except psycopg2.Error as e:
            if conn:
                conn.rollback()
            logging.error(f"Error executing query: {str(e)}")
            raise
        finally:
            if conn:
                self.return_connection(conn)

    def execute_one(self, query, params=None):
        """Execute a query and return one result with retry mechanism"""
        retry_count = 0
        while retry_count < self.MAX_RETRIES:
            conn = None
            try:
                conn = self.get_connection()
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    cur.execute(query, params)
                    result = cur.fetchone()
                    return result
            except (psycopg2.Error, psycopg2.InterfaceError) as e:
                retry_count += 1
                if retry_count == self.MAX_RETRIES:
                    logging.error(f"Final error executing query after {self.MAX_RETRIES} attempts: {str(e)}")
                    raise
                logging.warning(f"Retrying query, attempt {retry_count} of {self.MAX_RETRIES}")
                time.sleep(self.RETRY_DELAY)
                self._initialize_pool()
            finally:
                if conn and not conn.closed:
                    self.return_connection(conn)

    def execute_update(self, query, params=None):
        """Execute an update query"""
        conn = None
        try:
            conn = self.get_connection()
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query, params)
                result = cur.fetchone() if query.strip().upper().startswith("INSERT") and "RETURNING" in query.upper() else None
                conn.commit()
                return result
        except psycopg2.Error as e:
            if conn:
                conn.rollback()
            logging.error(f"Database error in execute_update: {str(e)}")
            raise Exception(f"Database error: {str(e)}")
        finally:
            if conn:
                self.return_connection(conn)

    def commit(self):
        """This method is kept for backward compatibility but is no longer needed"""
        pass  # Commits are handled in execute_update

    def rollback(self):
        """This method is kept for backward compatibility but is no longer needed"""
        pass  # Rollbacks are handled in individual methods